package com.centrychat.android.feature.settings

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.centrychat.android.BuildConfig
import com.centrychat.android.R
import com.centrychat.android.rememberSettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onLogout: () -> Unit,
) {
    val viewModel = rememberSettingsViewModel()
    val context = LocalContext.current
    val darkMode by viewModel.darkMode.collectAsStateWithLifecycle()
    val language by viewModel.language.collectAsStateWithLifecycle()

    var showLogoutDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back_button),
                        )
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState()),
        ) {
            // ── Appearance ────────────────────────────────────────────
            SectionLabel(stringResource(R.string.settings_appearance))
            ListItem(
                headlineContent = { Text(stringResource(R.string.settings_appearance_dark_mode)) },
                supportingContent = {
                    Text(when (darkMode) {
                        0 -> stringResource(R.string.settings_appearance_dark_mode_system)
                        1 -> stringResource(R.string.settings_appearance_dark_mode_on)
                        else -> stringResource(R.string.settings_appearance_dark_mode_off)
                    })
                },
                leadingContent = { Icon(Icons.Filled.Brightness6, contentDescription = null) },
                modifier = Modifier.clickable {
                    val next = when (darkMode) {
                        0 -> 1
                        1 -> 2
                        else -> 0
                    }
                    viewModel.setDarkMode(next)
                },
            )
            ListItem(
                headlineContent = { Text(stringResource(R.string.profile_field_language)) },
                supportingContent = { Text(language.uppercase()) },
                leadingContent = { Icon(Icons.Filled.Language, contentDescription = null) },
                modifier = Modifier.clickable {
                    val next = when (language) {
                        "en" -> "ar"
                        "ar" -> "fr"
                        else -> "en"
                    }
                    viewModel.setLanguage(next)
                },
            )

            HorizontalDivider(Modifier.padding(vertical = 12.dp))

            // ── Account ────────────────────────────────────────────────
            SectionLabel(stringResource(R.string.settings_account))
            ListItem(
                headlineContent = { Text(stringResource(R.string.settings_account_logout)) },
                leadingContent = { Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null) },
                modifier = Modifier.clickable { showLogoutDialog = true },
            )

            HorizontalDivider(Modifier.padding(vertical = 12.dp))

            // ── About ──────────────────────────────────────────────────
            SectionLabel(stringResource(R.string.settings_about))
            ListItem(
                headlineContent = { Text(stringResource(R.string.app_name)) },
                supportingContent = { Text(stringResource(R.string.settings_about_version, BuildConfig.VERSION_NAME)) },
                leadingContent = { Icon(Icons.Filled.Info, contentDescription = null) },
            )
            ListItem(
                headlineContent = { Text(stringResource(R.string.settings_about_open_website)) },
                leadingContent = { Icon(Icons.Filled.OpenInBrowser, contentDescription = null) },
                modifier = Modifier.clickable {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(BuildConfig.API_BASE_URL))
                    context.startActivity(intent)
                },
            )
            ListItem(
                headlineContent = { Text(stringResource(R.string.settings_about_privacy_policy)) },
                leadingContent = { Icon(Icons.Filled.Lock, contentDescription = null) },
                modifier = Modifier.clickable {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("${BuildConfig.API_BASE_URL}/privacy"))
                    context.startActivity(intent)
                },
            )
            ListItem(
                headlineContent = { Text(stringResource(R.string.settings_about_terms)) },
                leadingContent = { Icon(Icons.Filled.Lock, contentDescription = null) },
                modifier = Modifier.clickable {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("${BuildConfig.API_BASE_URL}/terms"))
                    context.startActivity(intent)
                },
            )
            ListItem(
                headlineContent = { Text("Backend") },
                supportingContent = { Text(BuildConfig.API_BASE_URL) },
            )
        }
    }

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = { Text(stringResource(R.string.settings_account_logout)) },
            text = { Text(stringResource(R.string.auth_logout_confirm)) },
            confirmButton = {
                TextButton(onClick = {
                    showLogoutDialog = false
                    viewModel.logout(onLogout)
                }) { Text(stringResource(R.string.settings_account_logout)) }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) {
                    Text(stringResource(R.string.action_cancel))
                }
            },
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
    )
}
