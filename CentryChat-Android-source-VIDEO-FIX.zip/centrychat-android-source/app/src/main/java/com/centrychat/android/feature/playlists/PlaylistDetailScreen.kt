package com.centrychat.android.feature.playlists

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.centrychat.android.R
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.LocalAppContainer
import com.centrychat.android.core.util.TimeFormatter
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.PlaylistArticleDto
import com.centrychat.android.data.model.PlaylistDto
import com.centrychat.android.data.model.PlaylistItemDto
import com.centrychat.android.data.repository.PlaylistsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * PlaylistDetailViewModel — loads a single playlist + its items (with
 * hydrated Article data) from the backend.
 *
 * Backend contract (mirrors the web):
 *   - `GET /api/v1/playlists/{id}`        → `{ playlist: PlaylistDto }`
 *     (wrapped — see [com.centrychat.android.data.model.PlaylistDto]).
 *   - `GET /api/v1/playlists/{id}/items`  → `{ items: PlaylistItemDto[] }`
 *     Each item has a `article: PlaylistArticleDto` field with the
 *     hydrated Article data (title, excerpt, coverImage, videoUrl,
 *     readingTime, author, ...).
 *
 * The previous version of this screen was a PLACEHOLDER — it rendered
 * "Playlist detail screen — full articles list coming soon." without
 * making any API call. So even when a playlist had items in the
 * backend, the Android client showed nothing.
 *
 * This ViewModel fetches the playlist metadata + its items in parallel
 * and exposes them as two StateFlows. The screen renders the playlist
 * header + a LazyColumn of items, where each item is a clickable card
 * that triggers the caller's `onArticleClick(articleId)` callback.
 */
class PlaylistDetailViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: PlaylistsRepository = appContainer.playlistsRepository

    private val _playlistState = MutableStateFlow<UiState<PlaylistDto>>(UiState.Loading)
    val playlistState: StateFlow<UiState<PlaylistDto>> = _playlistState.asStateFlow()

    private val _itemsState = MutableStateFlow<UiState<List<PlaylistItemDto>>>(UiState.Loading)
    val itemsState: StateFlow<UiState<List<PlaylistItemDto>>> = _itemsState.asStateFlow()

    fun load(playlistId: String) {
        _playlistState.value = UiState.Loading
        _itemsState.value = UiState.Loading
        viewModelScope.launch {
            try {
                val playlist = repo.getPlaylist(playlistId)
                _playlistState.value = UiState.Success(playlist)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _playlistState.value = UiState.Error(e.message ?: "Could not load playlist.")
            }
        }
        viewModelScope.launch {
            try {
                val items = repo.getItems(playlistId, limit = 200).items
                _itemsState.value = if (items.isEmpty()) UiState.Empty else UiState.Success(items)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _itemsState.value = UiState.Error(e.message ?: "Could not load playlist items.")
            }
        }
    }

    fun refresh(playlistId: String) = load(playlistId)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaylistDetailScreen(
    playlistId: String,
    onArticleClick: (String) -> Unit,
    onBack: () -> Unit,
) {
    val appContainer = LocalAppContainer.current
    val viewModel: PlaylistDetailViewModel = viewModel(
        factory = remember {
            object : androidx.lifecycle.ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T =
                    PlaylistDetailViewModel(appContainer) as T
            }
        }
    )

    val playlistState by viewModel.playlistState.collectAsStateWithLifecycle()
    val itemsState by viewModel.itemsState.collectAsStateWithLifecycle()

    LaunchedEffect(playlistId) { viewModel.load(playlistId) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        when (val s = playlistState) {
                            is UiState.Success -> s.data.name
                            else -> stringResource(R.string.playlists_title)
                        },
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back_button),
                        )
                    }
                },
            )
        },
    ) { padding ->
        Box(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentAlignment = Alignment.Center,
        ) {
            when (val ps = playlistState) {
                is UiState.Loading -> CircularProgressIndicator()
                is UiState.Error -> com.centrychat.android.ui.components.ErrorState(
                    message = ps.message,
                    onRetry = { viewModel.refresh(playlistId) },
                )
                is UiState.Empty -> com.centrychat.android.ui.components.EmptyState(
                    message = "Playlist not found.",
                )
                is UiState.Success -> {
                    Column(modifier = Modifier.fillMaxSize()) {
                        // ── Playlist header (name, description, item count) ─
                        PlaylistHeader(playlist = ps.data)

                        // ── Items list ────────────────────────────────────
                        when (val is_ = itemsState) {
                            is UiState.Loading -> Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center,
                            ) { CircularProgressIndicator() }
                            is UiState.Error -> com.centrychat.android.ui.components.ErrorState(
                                message = is_.message,
                                onRetry = { viewModel.refresh(playlistId) },
                            )
                            is UiState.Empty -> com.centrychat.android.ui.components.EmptyState(
                                message = "This playlist has no items yet.",
                            )
                            is UiState.Success -> LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                contentPadding = PaddingValues(
                                    horizontal = 12.dp, vertical = 8.dp,
                                ),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                items(is_.data, key = { it.id }) { item ->
                                    PlaylistItemCard(
                                        item = item,
                                        onClick = {
                                            // The article field carries the hydrated Article
                                            // data, with `id` mapped from `articleId` via
                                            // @SerialName. Use the hydrated `article.id` if
                                            // present, else fall back to the row's `articleId`.
                                            val articleId = item.article?.id ?: item.articleId
                                            if (articleId.isNotBlank()) onArticleClick(articleId)
                                        },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlaylistHeader(playlist: PlaylistDto) {
    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
        Text(
            text = playlist.name,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
        )
        if (!playlist.description.isNullOrBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(
                text = playlist.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Filled.PlaylistPlay,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp),
            )
            Spacer(Modifier.size(6.dp))
            Text(
                text = "${playlist.itemsCount} article(s)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun PlaylistItemCard(
    item: PlaylistItemDto,
    onClick: () -> Unit,
) {
    val article: PlaylistArticleDto? = item.article
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(12.dp)) {
            if (article == null) {
                // Edge case: item references an article that's no longer
                // published (the backend's hydrate function filters
                // non-PUBLISHED). Show a minimal row with the articleId.
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Article,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp),
                    )
                    Spacer(Modifier.size(8.dp))
                    Text(
                        text = "Article ${item.articleId.take(8)}…",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                // ── Cover image / video thumbnail ───────────────────────
                // The hydrated article has either a coverImage (article
                // with an image) OR a videoUrl (article with a video).
                // For video articles, the coverImage may serve as the
                // thumbnail; if only videoUrl is set, we show a video
                // play icon overlay on a 16:9 surface.
                val hasVideo = !article.videoUrl.isNullOrBlank()
                val hasImage = !article.coverImage.isNullOrBlank()
                if (hasImage) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                            .clip(RoundedCornerShape(8.dp)),
                    ) {
                        AsyncImage(
                            model = article.coverImage,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize(),
                        )
                        if (hasVideo) {
                            // Overlay a play icon when the article has a
                            // video. The article detail screen handles the
                            // actual playback via the article's `content`
                            // (HTML) or the `videoUrl` directly — depending
                            // on the article's media config.
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.PlayCircle,
                                    contentDescription = "Video",
                                    tint = androidx.compose.ui.graphics.Color.White,
                                    modifier = Modifier.size(48.dp),
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                } else if (hasVideo) {
                    // Video without a cover image — render a placeholder
                    // 16:9 surface with a play icon.
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                            .clip(RoundedCornerShape(8.dp)),
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(0.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                imageVector = Icons.Filled.PlayCircle,
                                contentDescription = "Video",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(56.dp),
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }
                // ── Title + excerpt ────────────────────────────────────
                Text(
                    text = article.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                article.excerpt?.let { ex ->
                    if (ex.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = ex,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                // ── Author + reading time + publishedAt ────────────────
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    article.author?.let { author ->
                        com.centrychat.android.ui.components.CentryChatAvatar(
                            fullName = author.fullName,
                            avatarColor = author.avatarColor,
                            avatarUrl = author.avatarUrl,
                            size = 18.dp,
                        )
                        Spacer(Modifier.size(6.dp))
                        Text(
                            text = "@${author.username}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(Modifier.size(8.dp))
                    }
                    article.readingTime?.let {
                        if (it > 0) {
                            Text(
                                text = "· ${it}m",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Spacer(Modifier.size(8.dp))
                        }
                    }
                    article.publishedAt?.let {
                        Text(
                            text = "· ${TimeFormatter.relative(it)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}
