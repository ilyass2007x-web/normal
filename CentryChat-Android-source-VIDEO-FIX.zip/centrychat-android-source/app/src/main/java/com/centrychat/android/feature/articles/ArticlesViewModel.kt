package com.centrychat.android.feature.articles

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.PaginatedState
import com.centrychat.android.data.model.ArticleCardDto
import com.centrychat.android.data.repository.ArticlesRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class ArticlesViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: ArticlesRepository = appContainer.articlesRepository

    private val _state = MutableStateFlow(PaginatedState<ArticleCardDto>())
    val state: StateFlow<PaginatedState<ArticleCardDto>> = _state

    init { refresh() }

    fun refresh() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null, endReached = false)
            try {
                val response = repo.getArticles(limit = 10)
                _state.value = PaginatedState(
                    items = response.articles,
                    cursor = response.nextCursor,
                    isLoading = false,
                    endReached = response.nextCursor == null,
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    isLoading = false,
                    error = e.message ?: "Could not load articles.",
                )
            }
        }
    }

    fun loadMore() {
        val current = _state.value
        if (current.isLoadingMore || current.endReached || current.cursor == null) return

        viewModelScope.launch {
            _state.value = current.copy(isLoadingMore = true)
            try {
                val next = repo.getArticles(cursor = current.cursor, limit = 10)
                _state.value = current.copy(
                    items = current.items + next.articles,
                    cursor = next.nextCursor,
                    isLoadingMore = false,
                    endReached = next.nextCursor == null,
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.value = current.copy(isLoadingMore = false, error = e.message)
            }
        }
    }
}
