package com.centrychat.android.feature.site_page

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.centrychat.android.CentryChatApp
import com.centrychat.android.R
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.SitePageDto
import com.centrychat.android.data.repository.MiscRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Public site page viewer (about / privacy / terms / contact).
 *
 * Fetches the page body from `/api/v1/site-pages/{slug}` and renders the
 * markdown content. The web app uses react-markdown; on Android, we
 * display the raw markdown body in a scrollable Text — a proper markdown
 * renderer can be added in a follow-up.
 *
 * Public endpoint — no session required.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SitePageScreen(
    slug: String,
    onBack: () -> Unit,
) {
    val ctx = LocalContext.current
    val repo = (ctx.applicationContext as? CentryChatApp)?.appContainer?.miscRepository
    var state by remember { mutableStateOf<UiState<SitePageDto>>(UiState.Loading) }
    val scope = remember { CoroutineScope(SupervisorJob() + Dispatchers.IO) }

    LaunchedEffect(slug) {
        if (repo == null) {
            state = UiState.Error("App container not available.")
            return@LaunchedEffect
        }
        scope.launch {
            try {
                val response = repo.getSitePage(slug)
                val page = response.page
                if (page == null) {
                    state = UiState.Error("Page not found.")
                } else {
                    state = UiState.Success(page)
                }
            } catch (e: Exception) {
                state = UiState.Error(e.message ?: "Could not load page.")
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        when (val s = state) {
                            is UiState.Success -> s.data.title
                            else -> slug.replaceFirstChar { it.uppercase() }
                        }
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        Box(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)
                .verticalScroll(rememberScrollState()),
            contentAlignment = Alignment.Center,
        ) {
            when (val s = state) {
                is UiState.Loading -> CircularProgressIndicator()
                is UiState.Error -> Text(
                    s.message,
                    color = MaterialTheme.colorScheme.error,
                )
                is UiState.Success -> Column {
                    Text(s.data.content, style = MaterialTheme.typography.bodyMedium)
                }
                is UiState.Empty -> Text(stringResource(R.string.site_page_not_found))
            }
        }
    }
}
