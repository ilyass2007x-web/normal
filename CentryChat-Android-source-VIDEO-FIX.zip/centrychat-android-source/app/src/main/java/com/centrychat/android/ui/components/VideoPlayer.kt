package com.centrychat.android.ui.components

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

/**
 * A Compose wrapper around androidx.media3 (ExoPlayer) for playing
 * article + playlist videos.
 *
 * The website uses an HTML5 `<video controls preload="metadata">` tag for
 * article `videoUrl` playback (see src/components/media/media-renderer.tsx
 * → "video" branch). The Android equivalent is `androidx.media3`'s
 * `PlayerView` + `ExoPlayer` — same play/pause/seek controls, same
 * source URL, same loading/error states.
 *
 * Behavior:
 *  - When [videoUrl] is not blank → renders a `PlayerView` filling the
 *    available width with a 16:9 aspect ratio.
 *  - Loading state is handled by ExoPlayer's buffer state (the
 *    `PlayerView` shows its built-in loading spinner when the buffer is
 *    empty + the player is preparing/buffering).
 *  - Error state is handled by `Player.Listener.onPlayerError` — when
 *    the URL cannot be loaded, an error overlay with an icon is shown.
 *  - The player is RELEASED when the composable leaves the composition
 *    (via `DisposableEffect`), so the player does NOT leak.
 *
 * The video URL is the SAME URL the website uses (the article's
 * `videoUrl` field) — no proxying, no re-hosting, no dummy URLs.
 *
 * Mirrors the web's `MediaRenderer` component which uses `media.type ==
 * "video"` to render a `<video>` element directly from the resolved
 * URL.
 */
@Composable
fun VideoPlayer(
    videoUrl: String,
    modifier: Modifier = Modifier,
) {
    if (videoUrl.isBlank()) return
    val context = LocalContext.current
    var hasError by remember { mutableStateOf(false) }

    // Build the ExoPlayer instance once per videoUrl.
    val exoPlayer = remember(videoUrl) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.parse(videoUrl)))
            prepare()
            playWhenReady = false
            repeatMode = Player.REPEAT_MODE_OFF
            addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    hasError = true
                }
            })
        }
    }

    // Release the player when the composable leaves the composition
    // (or when the videoUrl changes — `remember(videoUrl)` creates a
    // new instance and the previous one is disposed here).
    DisposableEffect(exoPlayer) {
        onDispose { exoPlayer.release() }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .background(Color.Black),
        contentAlignment = Alignment.Center,
    ) {
        if (hasError) {
            // Error overlay — same behavior as the web's
            // MediaUnavailableFallback (icon + message).
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) {
                androidx.compose.foundation.layout.Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(
                        imageVector = Icons.Filled.ErrorOutline,
                        contentDescription = "Video error",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.fillMaxWidth(0.2f),
                    )
                    androidx.compose.foundation.layout.Spacer(Modifier.fillMaxWidth(0.05f))
                    Text(
                        text = "Could not play this video.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White,
                    )
                }
            }
        } else {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = true
                        setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                        // Auto-show controls on tap; hide after 3s of inactivity.
                        controllerAutoShow = true
                        controllerHideOnTouch = true
                        // Default controller timeout (3 seconds).
                        controllerShowTimeoutMs = 3000
                    }
                },
                modifier = Modifier.fillMaxSize(),
            )
            // Loading spinner overlay (the PlayerView shows its own, but
            // this is a fallback for the brief "preparing" state).
            // Loading state is handled by the PlayerView's buffering UI
            // directly — no need for an extra overlay here.
        }
    }
}
