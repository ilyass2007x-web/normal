package com.centrychat.android.core.util

/**
 * String helpers for the UI layer.
 *
 * The CentryChat backend stores short posts as raw text (max 500 chars).
 * For long-form display in feed cards, we truncate with an ellipsis. The
 * same helper is used for article excerpts, comment previews, etc.
 */
object TextUtils {

    /** Truncate to [maxChars] characters + append an ellipsis. Preserves word
     *  boundaries when possible (the truncation point is the last space
     *  before the limit). */
    fun truncate(text: String, maxChars: Int = 280): String {
        if (text.length <= maxChars) return text
        val cut = text.substring(0, maxChars)
        val lastSpace = cut.lastIndexOf(' ').coerceAtLeast(0)
        return "${cut.substring(0, lastSpace)}…"
    }

    /** Format a number with thousands separators (e.g. 12345 → "12.3K"). */
    fun compactCount(count: Long): String {
        return when {
            count < 1_000 -> count.toString()
            count < 1_000_000 -> {
                val v = count / 100.0
                "${(v / 10.0).let { String.format("%.1f", it).trimEnd('0').trimEnd('.') }}K"
            }
            count < 1_000_000_000 -> {
                val v = count / 100_000.0
                "${String.format("%.1f", v / 10.0).trimEnd('0').trimEnd('.')}M"
            }
            else -> "${count / 1_000_000_000}B"
        }
    }

    /** Strip @mentions and #hashtags from a string for preview display. */
    fun stripMarkup(text: String): String {
        return text
            .replace(Regex("@[A-Za-z0-9_]+"), "")
            .replace(Regex("#[A-Za-z0-9_]+"), "")
            .trim()
    }

    /** True if the string is a valid email (RFC 5322 simplified check). */
    fun isValidEmail(email: String): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()
    }

    /** True if the string is a non-empty alphanumeric username (3-30 chars). */
    fun isValidUsername(username: String): Boolean {
        val pattern = Regex("^[A-Za-z0-9_]{3,30}$")
        return pattern.matches(username.trim())
    }

    // ────────────────────────────────────────────────────────────────────
    // URL extraction (mirrors src/lib/posts/parser.ts → URL_REGEX)
    // ────────────────────────────────────────────────────────────────────

    /**
     * The exact URL regex used by the website's `parsePostContent`
     * (src/lib/posts/parser.ts:72). Captures `https?://` or `//` followed
     * by a greedy run of non-whitespace, non-quote, non-<> characters.
     *
     * Reused on Android so Post content URLs are extracted identically to
     * the website — every URL the website would have rendered as an
     * `<a target="_blank">` is also detected here, then handed to the
     * [com.centrychat.android.ui.components.UnifiedVideoPlayer] for
     * resolution + inline playback (when the resolver classifies it as
     * video / embed).
     */
    private val URL_REGEX: Regex = Regex("""(?:https?://|//)[^\s<>"']+""", RegexOption.IGNORE_CASE)

    /** Trailing-punctuation chars to strip from a captured URL (matches the
     *  website's trailing punctuation trim — see parser.ts:118). */
    private val TRAILING_PUNCT = setOf('.', '!', '?', ',', ';', ':', ')', ']', '}', '\'', '"')

    /**
     * Extract every URL found in [content], in the order they appear.
     *
     * Mirrors `parsePostContent(content).urls` on the website. Each result
     * is the trimmed, `https:`-prefixed URL (a leading `//` is upgraded to
     * `https://`). Trailing sentence punctuation (`. , ! ? ; : ) ] } ' "`)
     * is stripped — the website does the same so a sentence like
     * `check https://example.com.` produces the URL `https://example.com`.
     *
     * Returns an empty list if [content] is null or blank or contains no
     * URLs. The list is de-duplicated while preserving first-seen order —
     * if the same URL appears twice in a Post, only the first occurrence is
     * returned (so the UI doesn't render the same video player twice).
     */
    fun extractUrls(content: String?): List<String> {
        if (content.isNullOrBlank()) return emptyList()
        val seen = LinkedHashSet<String>()
        URL_REGEX.findAll(content).forEach { m ->
            var raw = m.value
            if (raw.length < 4) return@forEach
            // Strip trailing punctuation (mirror website parser.ts:118-125).
            while (raw.length > 4 && raw.last() in TRAILING_PUNCT) {
                val last = raw.last()
                // Don't strip ')' if the URL contains an unbalanced '('
                // (handles "(see https://en.wikipedia.org/wiki/Foo_(bar))").
                if (last == ')' && raw.contains('(')) break
                raw = raw.dropLast(1)
            }
            // Normalize protocol-relative "//" → "https://"
            val url = if (raw.startsWith("//")) "https:$raw" else raw
            seen.add(url)
        }
        return seen.toList()
    }
}
