package com.centrychat.android.core.security

import com.centrychat.android.data.model.UserDto

/**
 * Role + permission helpers — mirror the web app's
 * `src/lib/permissions/index.ts` + `permissions.ts`.
 *
 * These helpers are CLIENT-SIDE GATES — they only hide UI affordances
 * from users who shouldn't see them. The BACKEND is the source of
 * truth: every `/api/v1/admin/[section]` route enforces `requireAdmin()` +
 * `requirePermission()` server-side, so even if a non-admin user
 * constructs an admin HTTP request manually (e.g. via adb), the
 * backend returns HTTP 403 + `{"ok":false,"error":{"message":"Forbidden"}}`.
 *
 * This file is therefore a UI convenience, NOT a security boundary.
 *
 * ROLE HIERARCHY (matches the web's ROLE_RANK):
 *   USER (0) < MODERATOR (1) < ADMIN (2) < SUPER_ADMIN (3)
 */
object Roles {

    const val USER = "USER"
    const val MODERATOR = "MODERATOR"
    const val ADMIN = "ADMIN"
    const val SUPER_ADMIN = "SUPER_ADMIN"

    /**
     * True if the [role] is ADMIN or SUPER_ADMIN.
     * Used to gate the Admin Dashboard entry in the UI.
     */
    fun canAccessAdmin(role: String?): Boolean {
        return role == ADMIN || role == SUPER_ADMIN
    }

    /**
     * True if the [role] is MODERATOR, ADMIN, or SUPER_ADMIN.
     * Used to gate moderation actions (currently informational —
     * the web app exposes no MODERATOR-only UI in the admin panel).
     */
    fun canModerate(role: String?): Boolean {
        return role == MODERATOR || canAccessAdmin(role)
    }

    fun isSuperAdmin(role: String?): Boolean = role == SUPER_ADMIN

    /**
     * Returns true if the [user] can see the Admin entry point
     * (bottom-nav item / settings row).
     *
     * Equivalent to the web's `canAccessAdmin(user.role)` check.
     */
    fun canAccessAdmin(user: UserDto?): Boolean = canAccessAdmin(user?.role)
}

/**
 * Permission keys — mirror the web's `permissions.ts` catalog (~60 keys).
 *
 * Each key is `<SECTION>_<ACTION>` where ACTION is VIEW or MANAGE.
 * Used to gate which admin sections a particular admin can access —
 * mirrors the web's `hasPermission(user, key)` check.
 *
 * NOTE: The Android client fetches the admin's actual permissions from
 * `GET /api/v1/admin/me/permissions` (returns `{role, permissions[], isSuperAdmin}`).
 * SUPER_ADMIN short-circuits to having all permissions.
 */
object Permissions {
    // Content management
    const val CONTENT_VIEW = "CONTENT_VIEW"
    const val CONTENT_MANAGE = "CONTENT_MANAGE"
    const val POSTS_VIEW = "POSTS_VIEW"
    const val POSTS_MANAGE = "POSTS_MANAGE"
    const val ARTICLES_VIEW = "ARTICLES_VIEW"
    const val ARTICLES_MANAGE = "ARTICLES_MANAGE"
    const val PLAYLISTS_VIEW = "PLAYLISTS_VIEW"
    const val PLAYLISTS_MANAGE = "PLAYLISTS_MANAGE"
    const val COLLECTIONS_VIEW = "COLLECTIONS_VIEW"
    const val COLLECTIONS_MANAGE = "COLLECTIONS_MANAGE"
    const val TOPICS_VIEW = "TOPICS_VIEW"
    const val TOPICS_MANAGE = "TOPICS_MANAGE"

    // User & community
    const val USERS_VIEW = "USERS_VIEW"
    const val USERS_MANAGE = "USERS_MANAGE"
    const val REPORTS_VIEW = "REPORTS_VIEW"
    const val REPORTS_MANAGE = "REPORTS_MANAGE"
    const val MODERATION_VIEW = "MODERATION_VIEW"
    const val MODERATION_MANAGE = "MODERATION_MANAGE"
    const val BLOCKED_DOMAINS_VIEW = "BLOCKED_DOMAINS_VIEW"
    const val BLOCKED_DOMAINS_MANAGE = "BLOCKED_DOMAINS_MANAGE"

    // Analytics
    const val ANALYTICS_VIEW = "ANALYTICS_VIEW"
    const val TRAFFIC_ANALYTICS_VIEW = "TRAFFIC_ANALYTICS_VIEW"
    const val SEARCH_ANALYTICS_VIEW = "SEARCH_ANALYTICS_VIEW"
    const val TRENDING_VIEW = "TRENDING_VIEW"

    // System + configuration
    const val SETTINGS_VIEW = "SETTINGS_VIEW"
    const val SETTINGS_MANAGE = "SETTINGS_MANAGE"
    const val FEATURES_VIEW = "FEATURES_VIEW"
    const val FEATURES_MANAGE = "FEATURES_MANAGE"
    const val HOMEPAGE_VIEW = "HOMEPAGE_VIEW"
    const val HOMEPAGE_MANAGE = "HOMEPAGE_MANAGE"
    const val SEO_VIEW = "SEO_VIEW"
    const val SEO_MANAGE = "SEO_MANAGE"
    const val CUSTOMIZATION_VIEW = "CUSTOMIZATION_VIEW"
    const val CUSTOMIZATION_MANAGE = "CUSTOMIZATION_MANAGE"
    const val SITE_PAGES_VIEW = "SITE_PAGES_VIEW"
    const val SITE_PAGES_MANAGE = "SITE_PAGES_MANAGE"
    const val APIS_VIEW = "APIS_VIEW"
    const val APIS_MANAGE = "APIS_MANAGE"
    const val NOTIFICATIONS_VIEW = "NOTIFICATIONS_VIEW"
    const val NOTIFICATIONS_MANAGE = "NOTIFICATIONS_MANAGE"
    const val EMAIL_VIEW = "EMAIL_VIEW"
    const val EMAIL_MANAGE = "EMAIL_MANAGE"
    const val VIDEO_CHAT_VIEW = "VIDEO_CHAT_VIEW"
    const val VIDEO_CHAT_MANAGE = "VIDEO_CHAT_MANAGE"
    const val AI_MODERATION_VIEW = "AI_MODERATION_VIEW"
    const val AI_MODERATION_MANAGE = "AI_MODERATION_MANAGE"
    const val RECOMMENDATION_VIEW = "RECOMMENDATION_VIEW"
    const val RECOMMENDATION_MANAGE = "RECOMMENDATION_MANAGE"
    const val TUTORIAL_VIDEOS_VIEW = "TUTORIAL_VIDEOS_VIEW"
    const val TUTORIAL_VIDEOS_MANAGE = "TUTORIAL_VIDEOS_MANAGE"
    const val SOCIAL_SHARING_VIEW = "SOCIAL_SHARING_VIEW"
    const val SOCIAL_SHARING_MANAGE = "SOCIAL_SHARING_MANAGE"
    const val ADS_VIEW = "ADS_VIEW"
    const val ADS_MANAGE = "ADS_MANAGE"

    // System / security / infra (view-only)
    const val SECURITY_VIEW = "SECURITY_VIEW"
    const val AUDIT_VIEW = "AUDIT_VIEW"
    const val DATABASE_VIEW = "DATABASE_VIEW"
    const val SYSTEM_VIEW = "SYSTEM_VIEW"
    const val SYSTEM_HEALTH_VIEW = "SYSTEM_HEALTH_VIEW"
    const val INFRASTRUCTURE_VIEW = "INFRASTRUCTURE_VIEW"

    /**
     * Returns true if the [permissions] set grants the [key].
     * SUPER_ADMIN short-circuits to true for everything (the backend
     * `getUserPermissions()` for a SUPER_ADMIN returns `Set("*"`).
     */
    fun hasPermission(permissions: Set<String>, key: String): Boolean {
        return permissions.contains("*") || permissions.contains(key)
    }
}
