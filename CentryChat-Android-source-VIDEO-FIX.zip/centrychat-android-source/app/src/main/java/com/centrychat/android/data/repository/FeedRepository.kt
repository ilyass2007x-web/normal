package com.centrychat.android.data.repository

import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.FeedItemDto
import com.centrychat.android.data.model.FeedResponse
import com.centrychat.android.data.model.safeApiCall

/**
 * The unified home feed repository.
 *
 * Pulls the ranked feed from `/api/v1/feed/unified` (recommended) and
 * `/api/v1/feed/trending` (non-personalized fallback).
 *
 * IMPORTANT: the ranking algorithm lives ENTIRELY in the backend
 * (`src/lib/content/ranking.ts` + `src/lib/feed/personalization.ts`).
 * The Android client does NOT re-rank, filter, or re-order items — it
 * only renders the items in the order the backend returns them.
 *
 * Pagination: cursor-based. Pass the `nextCursor` from the previous
 * response as `cursor` on the next request. `null` means there are no
 * more items.
 *
 * ERROR HANDLING: every API call goes through [safeApiCall] which extracts
 * the structured `error.message` from non-2xx responses. Without this,
 * the ViewModel would display a generic "HTTP ..." string from Retrofit's
 * default HttpException message.
 */
class FeedRepository(
    private val api: CentryChatApi,
) {
    /** Fetch the first page of the personalized feed (For You tab). */
    suspend fun getForYou(limit: Int = 20): FeedResponse {
        return safeApiCall { api.getUnifiedFeed(limit = limit, cursor = null, mix = null) }
    }

    /** Fetch the next page of the personalized feed. */
    suspend fun getForYouNext(cursor: String, limit: Int = 20): FeedResponse {
        return safeApiCall { api.getUnifiedFeed(limit = limit, cursor = cursor, mix = null) }
    }

    /** Fetch the first page of the trending feed (fallback when personalized
     *  feed is empty / the user isn't following anyone yet). */
    suspend fun getTrending(limit: Int = 20): FeedResponse {
        return safeApiCall { api.getTrendingFeed(limit = limit, cursor = null) }
    }

    /** Fetch the next page of the trending feed. */
    suspend fun getTrendingNext(cursor: String, limit: Int = 20): FeedResponse {
        return safeApiCall { api.getTrendingFeed(limit = limit, cursor = cursor) }
    }

    /** Flatten a feed response into individual items. */
    fun FeedResponse.items(): List<FeedItemDto> = items
}
