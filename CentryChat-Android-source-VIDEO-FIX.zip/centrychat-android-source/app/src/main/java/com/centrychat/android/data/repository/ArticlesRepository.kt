package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.ArticleCardDto
import com.centrychat.android.data.model.ArticleDetailDto
import com.centrychat.android.data.model.ArticleListResponse
import com.centrychat.android.data.model.CommentDto
import com.centrychat.android.data.model.CommentsResponse
import com.centrychat.android.data.model.ShareResponse
import com.centrychat.android.data.model.ToggleLikeResponse
import com.centrychat.android.data.model.safeApiCall

/**
 * Articles repository.
 *
 * Wraps the article list + article detail + article-like + article-comments
 * + article-share endpoints.
 *
 * Backend contracts (mirrors the web):
 *  - `GET /api/v1/articles`                  → `{ articles: ArticleCardDto[] }` (global)
 *  - `GET /api/v1/users/{username}/articles` → `{ articles: ArticleCardDto[] }` (per-user)
 *  - `GET /api/v1/articles/{id}`             → `{ article: ArticleDetailDto }` (wrapped)
 *  - `POST /api/v1/articles/{id}/like`       → `{ liked, likeCount }`
 *  - `POST /api/v1/articles/{id}/share`      → `{ shared, shareCount }`
 *  - `GET /api/v1/articles/{id}/comments`    → `{ comments, nextCursor, commentCount }`
 *  - `POST /api/v1/articles/{id}/comments`   → `{ comment: CommentDto }` (wrapped)
 *  - `POST /api/v1/article-comments/{id}/like` → `{ liked, likeCount }`
 *
 * ERROR HANDLING: every API call goes through [safeApiCall] which extracts
 * the structured `error.message` from non-2xx responses.
 *
 * ARTICLE DETAIL UNWRAPPING: the backend wraps the article detail under
 * `data.article` (NOT directly under `data`), so the API interface returns
 * [com.centrychat.android.data.model.ArticleDetailResponse] and we extract
 * `.article` here. See the ArticleDetailResponse KDoc for the rationale.
 */
class ArticlesRepository(
    private val api: CentryChatApi,
) {
    private val origin: String = BuildConfig.API_ORIGIN

    /** Fetch a paginated list of published articles. */
    suspend fun getArticles(cursor: String? = null, limit: Int = 10): ArticleListResponse {
        return safeApiCall { api.getArticles(limit = limit, cursor = cursor) }
    }

    /** Fetch a single article by ID (includes the full content body). */
    suspend fun getArticle(id: String): ArticleDetailDto {
        return safeApiCall { api.getArticle(id) }.article
    }

    /** Toggle like on an article. */
    suspend fun toggleLike(id: String): ToggleLikeResponse {
        return safeApiCall { api.toggleArticleLike(id = id, origin = origin) }
    }

    /**
     * Record a SHARE interaction on an article. Mirrors the web's
     * ArticleActions share-dialog behavior.
     *
     * Backend: `POST /api/v1/articles/{id}/share` (see
     * src/app/api/v1/articles/[id]/share/route.ts). Records an
     * ArticleInteraction row + increments the article's shareCount.
     * Returns the server-authoritative shareCount.
     *
     * @param method how the article was shared. "native" (default) for
     *               system-share, "link_copy" for copy-link, etc.
     */
    suspend fun shareArticle(id: String, method: String = "native"): ShareResponse {
        val body = mapOf<String, String?>("method" to method)
        return safeApiCall { api.shareArticle(id = id, body = body, origin = origin) }
    }

    /** Fetch paginated comments for an article (sorted by newest by default). */
    suspend fun getComments(
        articleId: String,
        limit: Int = 50,
    ): CommentsResponse {
        return safeApiCall { api.getArticleComments(id = articleId, limit = limit) }
    }

    /** Create a top-level comment or a reply (when parentCommentId is set). */
    suspend fun createComment(
        articleId: String,
        content: String,
        parentCommentId: String? = null,
    ): CommentDto {
        val body = buildMap {
            put("content", content)
            if (parentCommentId != null) put("parentCommentId", parentCommentId)
        }
        return safeApiCall {
            api.createArticleComment(id = articleId, body = body, origin = origin)
        }
    }

    /** Toggle like on an article comment (or reply). */
    suspend fun toggleCommentLike(commentId: String): ToggleLikeResponse {
        return safeApiCall { api.toggleArticleCommentLike(id = commentId, origin = origin) }
    }

    /** Convenience: fetch the first page of articles as a flat list. */
    suspend fun getFirstPage(limit: Int = 10): List<ArticleCardDto> {
        return getArticles(cursor = null, limit = limit).articles
    }

    /**
     * Fetch a specific user's published articles (and drafts if the
     *  viewer is the author).
     *
     *  Used by the Profile screen's Posts tab (merged with the user's
     *  Posts, mirroring the web's ProfilePosts layout: posts first,
     *  then articles). The global `/api/v1/articles` returns articles
     *  from ALL users — using it on Profile caused the wrong user's
     *  articles to render. This method calls
     *  `/api/v1/users/{username}/articles`, which the backend filters
     *  server-side by author.
     *
     *  @param limit default 50 — matches the backend's hard cap. Use
     *               a smaller value to reduce payload, but you'll get
     *               only the most-recent N articles.
     */
    suspend fun getUserArticles(username: String, limit: Int = 50): List<ArticleCardDto> {
        return safeApiCall { api.getUserArticles(username = username, limit = limit) }.articles
    }
}
