package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.MediaResolveRequest
import com.centrychat.android.data.model.ResolvedMediaDto
import com.centrychat.android.data.model.safeApiCall
import com.centrychat.android.data.model.toApiException

/**
 * Resolves any URL into a [ResolvedMediaDto] via `POST /api/v1/media/resolve`.
 *
 * Mirrors the website's `resolveMedia()` function (`src/lib/media/resolver.ts`)
 * and the `useMediaResolver` client hook (`src/hooks/use-media-resolver.ts`).
 *
 * Why this matters:
 *  - Article `videoUrl` on the backend is the RAW URL the author pasted.
 *    It can be a YouTube watch URL, a Vimeo link, a TikTok URL, a Pinterest
 *    pin, a direct .mp4, an HLS .m3u8 — the client doesn't know which.
 *  - The website NEVER passes `article.videoUrl` directly to `<video src=...>`.
 *    It ALWAYS calls `resolveMedia(article.videoUrl)` first to learn the
 *    `type` (video | embed | preview | unknown) + the playable `mediaUrl`.
 *  - The Android app MUST do the same — otherwise ExoPlayer receives a
 *    YouTube watch URL (HTML page, not a video file) and immediately throws
 *    `PlaybackException` → the "Could not play this video" error UI.
 *
 * The endpoint is auth-gated on the backend (`requireUser`). The OkHttp
 * client's PersistentCookieJar attaches the session cookie + the
 * AuthInterceptor adds the `Origin` header (CSRF check) on POST.
 */
class MediaRepository(
    private val api: CentryChatApi,
) {

    /**
     * Resolve [url] into a [ResolvedMediaDto].
     *
     * Returns a non-null [ResolvedMediaDto] in ALL of these cases:
     *  - Success → the resolved media (type may be "unknown" if the resolver
     *    couldn't classify the URL — but the object is still returned).
     *  - Resolver-side error (SSRF, network probe timeout, etc.) → the backend
     *    returns HTTP 200 with `media.type = "unknown"` + `note = "resolver-error"`.
     *
     * Returns null ONLY when the request itself fails (HTTP 4xx/5xx, network
     * outage, no session). In that case the caller (UnifiedVideoPlayer) shows
     * a retryable error overlay with the actual error message.
     */
    suspend fun resolve(url: String): ResolvedMediaDto? {
        val trimmed = url.trim()
        if (trimmed.isEmpty()) return null
        return try {
            val response = api.resolveMedia(
                body = MediaResolveRequest(url = trimmed),
                origin = BuildConfig.API_ORIGIN,
            )
            // Use safeApiCall so HTTP 4xx/5xx surface the backend's message.
            safeApiCall { response }.media
        } catch (e: retrofit2.HttpException) {
            val ex = e.toApiException()
            android.util.Log.w(
                TAG,
                "resolve: HTTP error for url=$trimmed — ${ex.message}",
            )
            null
        } catch (e: java.io.IOException) {
            android.util.Log.w(
                TAG,
                "resolve: network error for url=$trimmed — ${e.message}",
            )
            null
        } catch (e: Exception) {
            android.util.Log.e(
                TAG,
                "resolve: unexpected error for url=$trimmed",
                e,
            )
            null
        }
    }

    companion object {
        private const val TAG = "CentryChat/Media"
    }
}
