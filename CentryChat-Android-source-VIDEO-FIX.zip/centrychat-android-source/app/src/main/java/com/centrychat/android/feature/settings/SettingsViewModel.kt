package com.centrychat.android.feature.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.data.repository.AuthRepository
import com.centrychat.android.data.repository.SettingsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val authRepo: AuthRepository = appContainer.authRepository
    private val settingsRepo: SettingsRepository = appContainer.settingsRepository

    val darkMode: StateFlow<Int> = settingsRepo.darkModeFlow
        .stateIn(viewModelScope, SharingStarted.Lazily, 0)

    val language: StateFlow<String> = settingsRepo.languageFlow
        .stateIn(viewModelScope, SharingStarted.Lazily, "en")

    fun setDarkMode(value: Int) {
        viewModelScope.launch { settingsRepo.setDarkMode(value) }
    }

    fun setLanguage(value: String) {
        viewModelScope.launch { settingsRepo.setLanguage(value) }
    }

    fun logout(onComplete: () -> Unit) {
        viewModelScope.launch {
            try {
                authRepo.logout()
            } catch (_: Exception) {}
            onComplete()
        }
    }
}
