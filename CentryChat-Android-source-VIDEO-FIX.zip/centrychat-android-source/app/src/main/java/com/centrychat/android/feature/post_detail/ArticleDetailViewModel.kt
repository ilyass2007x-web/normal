package com.centrychat.android.feature.post_detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.ArticleDetailDto
import com.centrychat.android.data.model.CommentDto
import com.centrychat.android.data.repository.ArticlesRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Article detail screen ViewModel — loads a single article + its
 * comment thread, and handles the toggleLike / share / comment / reply
 * actions.
 *
 * Mirrors the PostDetailViewModel's behavior:
 *   - loadArticle + loadComments in parallel
 *   - toggleLike on the article (server-authoritative likeCount)
 *   - shareArticle (records a SHARE event on the backend)
 *   - sendComment (top-level + reply via parentCommentId)
 *   - toggleCommentLike on individual comments
 *
 * Backend contracts:
 *   - `GET /api/v1/articles/{id}`            → `{ article: ArticleDetailDto }`
 *   - `POST /api/v1/articles/{id}/like`      → `{ liked, likeCount }`
 *   - `POST /api/v1/articles/{id}/share`     → `{ shared, shareCount }`
 *   - `GET /api/v1/articles/{id}/comments`  → `{ comments, nextCursor, commentCount }`
 *   - `POST /api/v1/articles/{id}/comments`  → `{ comment: CommentDto }` (wrapped)
 *   - `POST /api/v1/article-comments/{id}/like` → `{ liked, likeCount }`
 */
class ArticleDetailViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: ArticlesRepository = appContainer.articlesRepository

    private val _state = MutableStateFlow<UiState<ArticleDetailDto>>(UiState.Loading)
    val state: StateFlow<UiState<ArticleDetailDto>> = _state.asStateFlow()

    private val _commentsState = MutableStateFlow<UiState<List<CommentDto>>>(UiState.Loading)
    val commentsState: StateFlow<UiState<List<CommentDto>>> = _commentsState.asStateFlow()

    private val _isSendingComment = MutableStateFlow(false)
    val isSendingComment: StateFlow<Boolean> = _isSendingComment.asStateFlow()

    private val _replyTarget = MutableStateFlow<CommentDto?>(null)
    val replyTarget: StateFlow<CommentDto?> = _replyTarget.asStateFlow()

    fun loadArticle(articleId: String) {
        _state.value = UiState.Loading
        viewModelScope.launch {
            try {
                val article = repo.getArticle(articleId)
                _state.value = UiState.Success(article)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.value = UiState.Error(e.message ?: "Could not load article.")
            }
        }
    }

    fun loadComments(articleId: String) {
        _commentsState.value = UiState.Loading
        viewModelScope.launch {
            try {
                val response = repo.getComments(articleId = articleId, limit = 100)
                _commentsState.value = if (response.comments.isEmpty()) {
                    UiState.Empty
                } else {
                    UiState.Success(response.comments)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _commentsState.value = UiState.Error(e.message ?: "Could not load comments.")
            }
        }
    }

    fun toggleLike(articleId: String) {
        viewModelScope.launch {
            try {
                val result = repo.toggleLike(articleId)
                val current = (_state.value as? UiState.Success)?.data ?: return@launch
                _state.value = UiState.Success(
                    current.copy(isLiked = result.liked, likeCount = result.likeCount)
                )
            } catch (_: Exception) {
                // best-effort
            }
        }
    }

    /**
     * Record a SHARE interaction on the article. Mirrors the web's
     * ArticleActions share-dialog behavior.
     */
    fun shareArticle(articleId: String) {
        viewModelScope.launch {
            try {
                val result = repo.shareArticle(articleId, method = "native")
                val current = (_state.value as? UiState.Success)?.data ?: return@launch
                _state.value = UiState.Success(
                    current.copy(shareCount = result.shareCount)
                )
            } catch (_: Exception) {
                // best-effort — share-tracking failure is non-fatal
            }
        }
    }

    fun toggleCommentLike(commentId: String) {
        viewModelScope.launch {
            try {
                val result = repo.toggleCommentLike(commentId)
                val current = (_commentsState.value as? UiState.Success)?.data ?: return@launch
                val updated = current.map { c ->
                    if (c.id == commentId) {
                        c.copy(isLiked = result.liked, likeCount = result.likeCount)
                    } else c
                }
                _commentsState.value = UiState.Success(updated)
            } catch (_: Exception) {
                // best-effort
            }
        }
    }

    fun sendComment(articleId: String, content: String, parentCommentId: String? = null) {
        if (content.isBlank() || _isSendingComment.value) return
        viewModelScope.launch {
            _isSendingComment.value = true
            try {
                val newComment = repo.createComment(
                    articleId = articleId,
                    content = content,
                    parentCommentId = parentCommentId,
                )
                val current = (_commentsState.value as? UiState.Success)?.data
                if (current != null) {
                    if (parentCommentId != null) {
                        // Insert as a reply to the parent comment.
                        val updated = current.map { c ->
                            if (c.id == parentCommentId) {
                                c.copy(replies = c.replies + newComment)
                            } else c
                        }
                        _commentsState.value = UiState.Success(updated)
                    } else {
                        // Insert as a new top-level comment.
                        _commentsState.value = UiState.Success(listOf(newComment) + current)
                    }
                }
                _replyTarget.value = null
                // Update the article's comment count
                val article = (_state.value as? UiState.Success)?.data
                if (article != null) {
                    _state.value = UiState.Success(article.copy(commentCount = article.commentCount + 1))
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // best-effort — the user can retry
            } finally {
                _isSendingComment.value = false
            }
        }
    }

    fun setReplyTarget(comment: CommentDto?) {
        _replyTarget.value = comment
    }
}
