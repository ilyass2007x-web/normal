package com.centrychat.android.feature.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.UserProfileSummary
import com.centrychat.android.data.repository.ProfileRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Followers / following list ViewModel.
 */
class FollowersViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: ProfileRepository = appContainer.profileRepository

    private val _state = MutableStateFlow<UiState<List<UserProfileSummary>>>(UiState.Loading)
    val state: StateFlow<UiState<List<UserProfileSummary>>> = _state.asStateFlow()

    fun load(username: String, isFollowers: Boolean) {
        _state.value = UiState.Loading
        viewModelScope.launch {
            try {
                val response = if (isFollowers) repo.getFollowers(username) else repo.getFollowing(username)
                _state.value = if (response.users.isEmpty()) UiState.Empty else UiState.Success(response.users)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.value = UiState.Error(e.message ?: "Could not load.")
            }
        }
    }
}
