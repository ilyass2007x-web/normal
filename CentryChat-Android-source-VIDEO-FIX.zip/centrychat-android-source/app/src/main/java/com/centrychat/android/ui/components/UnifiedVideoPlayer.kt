package com.centrychat.android.ui.components

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.centrychat.android.core.LocalAppContainer
import com.centrychat.android.data.model.ResolvedMediaDto
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ────────────────────────────────────────────────────────────────────────────
// PUBLIC ENTRY POINT
// ────────────────────────────────────────────────────────────────────────────

/**
 * Unified Media / Video Playback Layer for CentryChat on Android.
 *
 * Dispatches by URL kind, mirroring the website's `MediaRenderer` component
 * (`src/components/media/media-renderer.tsx`) which dispatches by
 * `media.type` returned by the universal resolver.
 *
 *  - YouTube URL       → WebView loading `youtube.com/embed/<id>` directly
 *  - Vimeo URL         → WebView loading `player.vimeo.com/video/<id>` directly
 *  - Direct MP4/HLS    → ExoPlayer with HLS/DASH/MP4 auto-detection
 *  - Unknown URL       → fall back to `POST /api/v1/media/resolve` and
 *                        dispatch by the returned `media.type`
 *
 * CRITICAL: this composable NEVER tries to play a YouTube/Vimeo URL as an
 * MP4 file. YouTube watch URLs are HTML pages, not video files — passing
 * them to ExoPlayer would throw `PlaybackException` immediately.
 *
 * USED BY:
 *  - ArticleDetailScreen → article videoUrl (Article Video)
 *  - PostDetailScreen / FeedScreen PostCard → URLs extracted from
 *    post.content (Post Video)
 *  - PlaylistDetailScreen → opens an Article, then ArticleDetailScreen
 *    handles the video (Playlist Video IS Article Video — same contract).
 *
 * LIFECYCLE: the player/WebView is created once per [rawUrl] and released
 * when the composable leaves the composition OR when [rawUrl] changes.
 * LifecycleEventObserver pauses/resumes playback when the app goes
 * background. No unnecessary refresh, no repeated player recreation.
 *
 * @param rawUrl    the URL to play (article.videoUrl, a URL extracted from
 *                  post.content, or any raw URL).
 * @param posterUrl optional poster/thumbnail URL — rendered on the
 *                  fallback card for non-video / non-embed cases.
 * @param modifier  outer modifier (the composable always fills the width +
 *                  enforces a 16:9 aspect ratio).
 */
@Composable
fun UnifiedVideoPlayer(
    rawUrl: String?,
    modifier: Modifier = Modifier,
    posterUrl: String? = null,
) {
    val tag = "CentryChat/Video"
    val appContainer = LocalAppContainer.current

    // ── Classify locally FIRST (no network call) ────────────────────────
    // This avoids the "reload" behavior + black screen for known patterns.
    val kind: VideoKind = remember(rawUrl) {
        VideoUrlClassifier.classify(rawUrl)
    }

    // For unknown URLs, we still need the resolver — track its state.
    var resolverState by remember(rawUrl) {
        mutableStateOf<ResolverState>(ResolverState.Idle)
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .background(Color.Black)
            // ── CRITICAL: consume parent click events ──────────────────────────
            // Without this, tapping the video area inside a `Card(onClick = ...)`
            // (e.g. FeedScreen.PostCard) propagates up to the Card's onClick,
            // which navigates to PostDetailScreen — the user perceives this as
            // "the app does refresh/reload when I tap the video".
            //
            // We add a no-op clickable layer (with NO ripple indication so the
            // UX stays clean) that consumes tap events on the video bounds.
            // The AndroidView (PlayerView / WebView) is rendered ON TOP of
            // this Box's clickable layer, so it still receives its own taps
            // (ExoPlayer play/pause buttons, YouTube embed play button, etc.)
            // — only taps on the empty/black area around the player surface
            // are consumed by this no-op.
            .clickableNoOp(),
        contentAlignment = Alignment.Center,
    ) {
        when (val k = kind) {
            is VideoKind.YouTube -> {
                android.util.Log.i(tag, "YouTube detected: videoId=${k.videoId} (from $rawUrl)")
                YouTubeEmbedPlayer(videoId = k.videoId, tag = tag)
            }
            is VideoKind.Vimeo -> {
                android.util.Log.i(tag, "Vimeo detected: videoId=${k.videoId} (from $rawUrl)")
                VimeoEmbedPlayer(videoId = k.videoId, tag = tag)
            }
            is VideoKind.DirectVideo -> {
                android.util.Log.i(tag, "Direct video detected: url=${k.url} mime=${k.mimeHint}")
                ExoPlayerSurface(
                    videoUrl = k.url,
                    contentType = k.mimeHint,
                    posterUrl = posterUrl,
                    tag = tag,
                )
            }
            VideoKind.Unknown -> {
                // Fall back to the resolver — used for unusual URLs that
                // don't match the YouTube/Vimeo/direct-extension patterns.
                // (e.g. Pinterest pins, Reddit posts, redirect-shortened
                // links, or URLs whose Content-Type the resolver needs to
                // probe server-side.)
                UnknownUrlHandler(
                    rawUrl = rawUrl,
                    state = resolverState,
                    onStateChange = { resolverState = it },
                    posterUrl = posterUrl,
                    tag = tag,
                    appContainer = appContainer,
                )
            }
        }
    }
}

// ────────────────────────────────────────────────────────────────────────────
// UNKNOWN URL HANDLER — calls the resolver, then dispatches
// ────────────────────────────────────────────────────────────────────────────

@Composable
private fun UnknownUrlHandler(
    rawUrl: String?,
    state: ResolverState,
    onStateChange: (ResolverState) -> Unit,
    posterUrl: String?,
    tag: String,
    appContainer: com.centrychat.android.core.AppContainer,
) {
    LaunchedEffect(rawUrl) {
        if (rawUrl.isNullOrBlank()) {
            onStateChange(ResolverState.Idle)
            return@LaunchedEffect
        }
        onStateChange(ResolverState.Loading)
        android.util.Log.i(tag, "Unknown URL — calling resolver: $rawUrl")
        val media = withContext(Dispatchers.IO) {
            appContainer.mediaRepository.resolve(rawUrl)
        }
        if (media == null) {
            android.util.Log.w(tag, "Resolver FAILED (network/HTTP error) for URL: $rawUrl")
            onStateChange(ResolverState.Failed(
                "Could not resolve media. Check your connection and try again.",
            ))
        } else {
            android.util.Log.i(
                tag,
                "Resolved: type=${media.type} provider=${media.provider} " +
                    "mediaUrl='${media.mediaUrl}' embedUrl='${media.embedUrl}' " +
                    "contentType='${media.contentType}' note='${media.note}'",
            )
            onStateChange(ResolverState.Resolved(media))
        }
    }

    when (state) {
        ResolverState.Idle -> {
            // No URL — render nothing (caller usually guards first).
        }
        ResolverState.Loading -> CircularProgressIndicator(
            color = Color.White,
            strokeWidth = 2.dp,
            modifier = Modifier.size(36.dp),
        )
        is ResolverState.Resolved -> ResolvedMediaSurface(
            media = state.media,
            posterUrl = posterUrl,
            tag = tag,
        )
        is ResolverState.Failed -> ErrorOverlay(message = state.message)
    }
}

@Composable
private fun ResolvedMediaSurface(
    media: ResolvedMediaDto,
    posterUrl: String?,
    tag: String,
) {
    when (media.type.lowercase()) {
        "video" -> {
            val playUrl = media.mediaUrl.ifBlank { media.originalUrl }
            if (playUrl.isBlank()) {
                FallbackOpenOriginalCard(
                    originalUrl = media.originalUrl,
                    message = "Video URL is empty.",
                )
            } else {
                ExoPlayerSurface(
                    videoUrl = playUrl,
                    contentType = media.contentType,
                    posterUrl = posterUrl ?: media.thumbnailUrl,
                    tag = tag,
                )
            }
        }
        "embed" -> {
            val embedUrl = media.embedUrl ?: media.mediaUrl
            if (embedUrl.isBlank()) {
                FallbackOpenOriginalCard(
                    originalUrl = media.originalUrl,
                    message = "Embed URL is empty.",
                )
            } else {
                GenericEmbedWebView(embedUrl = embedUrl, tag = tag)
            }
        }
        "image" -> {
            coil.compose.AsyncImage(
                model = media.mediaUrl.ifBlank { media.originalUrl },
                contentDescription = null,
                contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                modifier = Modifier.fillMaxSize(),
            )
        }
        else -> {
            android.util.Log.i(
                tag,
                "type=${media.type} → fallback card (provider=${media.provider} note=${media.note})",
            )
            FallbackOpenOriginalCard(
                originalUrl = media.originalUrl,
                message = when (media.type.lowercase()) {
                    "preview" -> "Preview not available on the app."
                    else -> "This media type isn't supported in the app yet."
                },
            )
        }
    }
}

// ────────────────────────────────────────────────────────────────────────────
// YOUTUBE EMBED PLAYER — loads youtube.com/embed/<id> DIRECTLY in WebView
// ────────────────────────────────────────────────────────────────────────────

/**
 * Renders a YouTube video inside a properly-configured Android WebView.
 *
 * CRITICAL DIFFERENCE vs the old EmbedWebView:
 *  - OLD: loadDataWithBaseURL("sentrychat.netlify.app/", "<html><iframe src=youtube-nocookie.com/embed/...></html>", ...)
 *         → cross-origin iframe inside a data-URI-base page → YouTube renders blank/black
 *  - NEW: webView.loadUrl("https://www.youtube.com/embed/<id>?rel=0&playsinline=1&modestbranding=1")
 *         → the WebView BECOMES the embed page → YouTube IFrame API works as designed
 *
 * The embed URL is built from the videoId using the same pattern as the
 * website's `parseYouTube` (which uses `youtube-nocookie.com/embed/<id>`),
 * but we use the regular `youtube.com/embed/` host because:
 *  - Some Android WebView versions have issues with `youtube-nocookie.com`
 *    (Privacy-enhanced mode sets stricter SameSite cookies that can break
 *    the IFrame API).
 *  - The regular `youtube.com/embed/` host is what the official YouTube
 *    IFrame API samples use.
 *
 * Lifecycle: the WebView is paused when the host Lifecycle goes ON_PAUSE
 * and resumed when it goes ON_RESUME — this prevents the YouTube player
 * from continuing playback in the background when the user navigates away.
 * The WebView is destroyed when the composable leaves the composition.
 */
@Composable
private fun YouTubeEmbedPlayer(
    videoId: String,
    tag: String,
) {
    val embedUrl = remember(videoId) {
        // Standard YouTube IFrame embed URL. Parameters mirror the website's
        // `<iframe>` sandbox allow list + the article-reading-page UX.
        //   rel=0             — don't show related videos from other channels
        //   playsinline=1     — play inline on iOS (also respects Android fullscreen)
        //   modestbranding=1  — minimal YouTube logo
        "https://www.youtube.com/embed/$videoId?rel=0&playsinline=1&modestbranding=1"
    }
    EmbedWebView(
        url = embedUrl,
        tag = tag,
        label = "YouTube embed",
    )
}

// ────────────────────────────────────────────────────────────────────────────
// VIMEO EMBED PLAYER — loads player.vimeo.com/video/<id> DIRECTLY in WebView
// ────────────────────────────────────────────────────────────────────────────

/**
 * Renders a Vimeo video inside a properly-configured Android WebView.
 *
 * Loads `https://player.vimeo.com/video/<id>` DIRECTLY — the WebView
 * BECOMES the Vimeo player iframe (no HTML wrapper, no iframe-inside-page).
 *
 * Vimeo's player.vimeo.com host is the official embed host — the same URL
 * the website's resolver returns in `embedUrl`.
 */
@Composable
private fun VimeoEmbedPlayer(
    videoId: String,
    tag: String,
) {
    val embedUrl = remember(videoId) {
        "https://player.vimeo.com/video/$videoId"
    }
    EmbedWebView(
        url = embedUrl,
        tag = tag,
        label = "Vimeo embed",
    )
}

/**
 * Generic embed WebView — used when the resolver returned `type=embed` for
 * a URL the local classifier couldn't recognize (e.g. TikTok, Instagram).
 *
 * Loads the embed URL DIRECTLY in the WebView (no iframe wrapper).
 */
@Composable
private fun GenericEmbedWebView(
    embedUrl: String,
    tag: String,
) {
    EmbedWebView(
        url = embedUrl,
        tag = tag,
        label = "Generic embed",
    )
}

// ────────────────────────────────────────────────────────────────────────────
// SHARED EMBED WEBVIEW — loads a URL DIRECTLY, with proper lifecycle
// ────────────────────────────────────────────────────────────────────────────

/**
 * The shared WebView surface for ALL embed types (YouTube / Vimeo / generic).
 *
 * Loads [url] DIRECTLY via `WebView.loadUrl()` — the WebView becomes the
 * embed page (NOT an HTML wrapper containing an iframe). This is the
 * correct way to embed YouTube/Vimeo on Android — the official IFrame APIs
 * are designed for this.
 *
 * Lifecycle:
 *  - ON_PAUSE → `webView.onPause()` — pauses video + JS timers.
 *  - ON_RESUME → `webView.onResume()` — resumes.
 *  - On dispose → `webView.destroy()` — frees native resources.
 *
 * WebView config (mirrors the website's `<iframe>` sandbox):
 *  - javaScriptEnabled = true
 *  - domStorageEnabled = true
 *  - mediaPlaybackRequiresUserGesture = false  (allow autoplay)
 *  - allowFileAccess = false                   (defensive sandbox)
 *  - allowContentAccess = true                 (embed needs to fetch JS/CSS)
 *  - mixedContentMode = MIXED_CONTENT_NEVER_ALLOW  (block HTTP subresources)
 *  - useWideViewPort + loadWithOverviewMode = true (responsive fill)
 *  - WebViewClient: open external links in the browser (not the WebView)
 *  - WebChromeClient: default — handles fullscreen video + alerts
 */
@Composable
private fun EmbedWebView(
    url: String,
    tag: String,
    label: String,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // Hold the WebView in a remember so the AndroidView factory can be
    // called once, and the update block can re-target it if [url] changes.
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                // ── Layout params ────────────────────────────────────────
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                )

                // ── Settings (sandbox-equivalent) ───────────────────────
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    mediaPlaybackRequiresUserGesture = false
                    allowFileAccess = false
                    allowContentAccess = true
                    mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    cacheMode = WebSettings.LOAD_DEFAULT
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    // Disable zoom UI (embeds are responsive anyway).
                    setSupportZoom(false)
                    builtInZoomControls = false
                    displayZoomControls = false
                    // CRITICAL: a real-browser User-Agent. YouTube + Vimeo
                    // serve a "your browser is not supported" page (or no
                    // video at all) when the default Android WebView UA is
                    // detected. We use the Chrome desktop UA string so the
                    // embeds render the full-featured desktop player.
                    userAgentString =
                        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 " +
                        "(KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36"
                }

                // ── Cookies — REQUIRED for YouTube + Vimeo embeds ──────────
                // YouTube embeds (especially the youtube-nocookie.com variant)
                // set + read cookies for session + preference state. Without
                // accepting cookies, the YouTube IFrame API fails to load the
                // video + the player shows a black/blank screen.
                //
                // Vimeo's player.vimeo.com host sets a `vuid` cookie that the
                // player requires for analytics + playback state.
                //
                // We enable both first-party + third-party cookies for the
                // WebView (third-party is needed because the embed page is on
                // youtube.com/embed/ but resources load from googlevideo.com
                // and ytimg.com — different origins).
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

                // ── WebViewClient — block ALL navigation, never open Chrome ─
                // CRITICAL FIX: the previous implementation called
                //   Intent(Intent.ACTION_VIEW, Uri.parse(target))
                //   context.startActivity(intent)
                // for any URL != the embed URL. When the YouTube embed tries
                // to load any subresource or the user taps the YouTube logo,
                // this fired → opened Chrome in the background → the WebView
                // showed a black screen + the user perceived the Chrome
                // launch as "the app does refresh/reload".
                //
                // NEW behavior: block ALL navigation silently. The embed
                // page stays put. The user can interact with the player
                // (play, pause, fullscreen, seek) but cannot navigate away.
                // This guarantees Chrome NEVER opens from the embed WebView.
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        view: WebView?,
                        request: WebResourceRequest?,
                    ): Boolean {
                        // BLOCK all navigation. Return true → the URL is NOT
                        // loaded into the WebView AND no external Intent is
                        // fired. The embed page stays put.
                        val target = request?.url?.toString() ?: "(unknown)"
                        android.util.Log.d(tag, "$label → blocked navigation to: $target")
                        return true
                    }

                    override fun onPageStarted(
                        view: WebView?,
                        url: String?,
                        favicon: Bitmap?,
                    ) {
                        android.util.Log.i(tag, "$label → onPageStarted: $url")
                    }

                    override fun onPageFinished(
                        view: WebView?,
                        url: String?,
                    ) {
                        android.util.Log.i(tag, "$label → onPageFinished: $url")
                        // Flush any cookies set during the page load so they
                        // persist across app restarts (CookieManager's default
                        // is in-memory only; flush() writes them to disk).
                        CookieManager.getInstance().flush()
                    }

                    override fun onReceivedError(
                        view: WebView?,
                        request: WebResourceRequest?,
                        error: WebResourceError?,
                    ) {
                        // Don't log subresource errors — they're noisy (ads,
                        // tracking pixels, font fallbacks). Only log the
                        // main frame errors.
                        if (request?.isForMainFrame == true) {
                            android.util.Log.e(
                                tag,
                                "$label → main-frame error: ${error?.description} (code=${error?.errorCode}) for ${request.url}",
                            )
                        }
                    }

                    override fun onReceivedHttpError(
                        view: WebView?,
                        request: WebResourceRequest?,
                        errorResponse: WebResourceResponse?,
                    ) {
                        if (request?.isForMainFrame == true) {
                            android.util.Log.e(
                                tag,
                                "$label → HTTP ${errorResponse?.statusCode} ${errorResponse?.reasonPhrase} for ${request.url}",
                            )
                        }
                    }
                }

                // ── WebChromeClient — handles fullscreen video + JS dialogs ─
                // YouTube + Vimeo embeds use the HTML5 Fullscreen API when
                // the user taps the fullscreen button. Without a
                // WebChromeClient that implements onShowCustomView /
                // onHideCustomView, the fullscreen tap silently fails.
                //
                // The default WebChromeClient() handles these — we just
                // need to instantiate it (the previous code already did,
                // but we add logging on onShowCustomView for diagnostics).
                webChromeClient = object : WebChromeClient() {
                    override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                        android.util.Log.d(tag, "$label → onShowCustomView (fullscreen requested)")
                        super.onShowCustomView(view, callback)
                    }

                    override fun onHideCustomView() {
                        android.util.Log.d(tag, "$label → onHideCustomView (fullscreen exited)")
                        super.onHideCustomView()
                    }
                }

                // ── Load the embed URL DIRECTLY ─────────────────────────
                // CRITICAL: this is `loadUrl`, NOT `loadDataWithBaseURL`.
                // The WebView BECOMES the embed page (the YouTube/Vimeo
                // IFrame API is designed for this).
                android.util.Log.i(tag, "$label → loadUrl: $url")
                loadUrl(url)

                webViewRef = this
            }
        },
        update = { /* No-op — the WebView is configured in factory and the
                     URL is fixed per composable instance (when rawUrl changes
                     we get a brand-new composable instance via remember(rawUrl)
                     in UnifiedVideoPlayer). */ },
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
    )

    // ── Lifecycle: pause/resume/destroy ────────────────────────────────
    DisposableEffect(lifecycleOwner, url) {
        val observer = LifecycleEventObserver { _, event ->
            val wv = webViewRef
            if (wv != null) {
                when (event) {
                    Lifecycle.Event.ON_PAUSE -> {
                        android.util.Log.d(tag, "$label → onPause (lifecycle)")
                        runCatching { wv.onPause() }
                    }
                    Lifecycle.Event.ON_RESUME -> {
                        android.util.Log.d(tag, "$label → onResume (lifecycle)")
                        runCatching { wv.onResume() }
                    }
                    Lifecycle.Event.ON_DESTROY -> {
                        android.util.Log.d(tag, "$label → destroy (lifecycle ON_DESTROY)")
                        runCatching { wv.destroy() }
                    }
                    else -> { /* ignore */ }
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            val wv = webViewRef
            if (wv != null) {
                android.util.Log.d(tag, "$label → dispose → destroy WebView")
                runCatching {
                    wv.stopLoading()
                    wv.onPause()
                    (wv.parent as? ViewGroup)?.removeView(wv)
                    wv.destroy()
                }
                webViewRef = null
            }
        }
    }
}

// ────────────────────────────────────────────────────────────────────────────
// EXOPLAYER SURFACE — plays MP4, HLS (.m3u8), DASH (.mpd), WebM, OGG
// ────────────────────────────────────────────────────────────────────────────

/**
 * The ExoPlayer-backed video surface for direct video files (MP4, HLS,
 * DASH, WebM, OGG). Used both:
 *  - Directly, when [VideoUrlClassifier] classifies the URL as DirectVideo.
 *  - Indirectly, when the resolver returns `type=video` for an unknown URL.
 *
 * WIRED UP:
 *  - DefaultHttpDataSource.Factory: User-Agent `CentryChat/Android 1.0`,
 *    cross-protocol redirects, 15s connect/read timeouts, Range requests.
 *  - DefaultMediaSourceFactory: auto-detects HLS / DASH / MP4 / WebM / OGG
 *    from the URI extension + the MIME hint (when [contentType] is set).
 *  - Player.Listener.onPlayerError: full diagnostic log under
 *    `CentryChat/Video` — errorCode, errorCodeName, URI, content-type,
 *    full cause chain 6 levels deep, human-readable message mapping
 *    IO_NETWORK / IO_BAD_HTTP_STATUS / PARSING / DECODER / DRM categories.
 *  - Lifecycle: ON_PAUSE → `player.pause()`; ON_RESUME → no auto-resume
 *    (the user controls playback); ON_DESTROY / onDispose → `player.release()`.
 *
 * The player is keyed on [videoUrl] — a stable [videoUrl] means the player
 * is created ONCE + released when the composable leaves the composition.
 * No repeated recreation, no black screen from a fresh preparing state.
 */
@Composable
private fun ExoPlayerSurface(
    videoUrl: String,
    contentType: String?,
    posterUrl: String?,
    tag: String,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var hasError by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(true) }

    // Build the HTTP data source factory once.
    val httpFactory = remember {
        DefaultHttpDataSource.Factory()
            .setUserAgent("CentryChat/Android 1.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(15_000)
    }

    // Build the media source factory once.
    val mediaSourceFactory = remember(httpFactory) {
        DefaultMediaSourceFactory(context).setDataSourceFactory(httpFactory)
    }

    val exoPlayer = remember(videoUrl) {
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(mediaSourceFactory)
            .build().apply {
                val mediaItemBuilder = MediaItem.Builder().setUri(Uri.parse(videoUrl))
                contentType?.let { ct ->
                    val mime = normalizeMimeType(ct)
                    if (mime != null) mediaItemBuilder.setMimeType(mime)
                }
                setMediaItem(mediaItemBuilder.build())
                prepare()
                playWhenReady = false
                repeatMode = Player.REPEAT_MODE_OFF
                addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        val errorCode = error.errorCode
                        val errorCodeName = error.errorCodeName
                        val cause = error.cause
                        val uri = try {
                            currentMediaItem?.localConfiguration?.uri?.toString()
                        } catch (_: Exception) {
                            "(unavailable)"
                        }
                        android.util.Log.e(
                            tag,
                            "Player error: code=$errorCode name='$errorCodeName' " +
                                "url=$uri contentType=$contentType cause=${cause?.javaClass?.name}: ${cause?.message}",
                        )
                        var c: Throwable? = error
                        var depth = 0
                        while (c != null && depth < 6) {
                            android.util.Log.e(
                                tag,
                                "  cause[$depth]: ${c.javaClass.simpleName} — ${c.message}",
                            )
                            c = c.cause
                            depth++
                        }
                        hasError = true
                        errorMessage = humanReadableError(errorCode, errorCodeName, cause)
                    }

                    override fun onPlaybackStateChanged(state: Int) {
                        when (state) {
                            Player.STATE_READY -> isLoading = false
                            Player.STATE_BUFFERING -> isLoading = true
                            Player.STATE_ENDED -> isLoading = false
                            Player.STATE_IDLE -> isLoading = false
                        }
                    }
                })
            }
    }

    // Pause on lifecycle ON_PAUSE, release on ON_DESTROY + onDispose.
    DisposableEffect(lifecycleOwner, exoPlayer) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> {
                    android.util.Log.d(tag, "ExoPlayer → pause (lifecycle ON_PAUSE)")
                    runCatching { exoPlayer.pause() }
                }
                Lifecycle.Event.ON_RESUME -> {
                    // Don't auto-resume — let the user tap play.
                }
                Lifecycle.Event.ON_DESTROY -> {
                    android.util.Log.d(tag, "ExoPlayer → release (lifecycle ON_DESTROY)")
                    runCatching { exoPlayer.release() }
                }
                else -> { /* ignore */ }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            android.util.Log.d(tag, "ExoPlayer → release (dispose)")
            runCatching { exoPlayer.release() }
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center,
    ) {
        if (hasError) {
            ErrorOverlay(
                message = errorMessage ?: "Could not play this video.",
                retryHint = "Tap to retry",
                onRetry = {
                    hasError = false
                    errorMessage = null
                    isLoading = true
                    exoPlayer.seekTo(0)
                    exoPlayer.prepare()
                },
            )
        } else {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = true
                        setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                        controllerAutoShow = true
                        controllerHideOnTouch = true
                        controllerShowTimeoutMs = 3000
                    }
                },
                modifier = Modifier.fillMaxSize(),
            )
            if (isLoading) {
                CircularProgressIndicator(
                    color = Color.White.copy(alpha = 0.7f),
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(36.dp),
                )
            }
        }
    }
}

/**
 * Map a backend `Content-Type` (or our local extension-derived MIME) to a
 * Media3 MIME type. Returns null when not a recognized video MIME — let
 * ExoPlayer infer from the URI extension in that case.
 */
private fun normalizeMimeType(contentType: String): String? {
    val ct = contentType.lowercase().trim()
    return when {
        ct.startsWith("video/mp4") || ct.startsWith("video/quicktime") -> MimeTypes.VIDEO_MP4
        ct.startsWith("video/webm") -> MimeTypes.VIDEO_WEBM
        ct.startsWith("application/vnd.apple.mpegurl") || ct.contains("m3u8") -> MimeTypes.APPLICATION_M3U8
        ct.startsWith("application/dash+xml") || ct.contains("mpd") -> MimeTypes.APPLICATION_MPD
        ct.startsWith("video/ogg") || ct.startsWith("application/ogg") -> MimeTypes.VIDEO_OGG
        ct.startsWith("video/mp2t") -> MimeTypes.VIDEO_MP2T
        ct.startsWith("audio/") -> MimeTypes.AUDIO_AAC
        else -> null
    }
}

/**
 * Convert a Media3 [PlaybackException] into a one-line human-readable hint.
 * Matches on [PlaybackException.errorCodeName] (a stable string) rather
 * than the volatile numeric constants.
 */
private fun humanReadableError(
    errorCode: Int,
    errorCodeName: String,
    cause: Throwable?,
): String {
    return when {
        errorCodeName.startsWith("ERROR_CODE_IO_NETWORK") ->
            "Network connection failed. Check your internet and tap to retry."
        errorCodeName.startsWith("ERROR_CODE_IO_BAD_HTTP_STATUS") ||
            errorCodeName.startsWith("ERROR_CODE_IO_INVALID_HTTP_CONTENT_TYPE") ->
            "The video host returned an error (HTTP). The URL may be expired or signed-only."
        errorCodeName.startsWith("ERROR_CODE_PARSING") ->
            "The video file could not be parsed. The format may not be supported."
        errorCodeName.startsWith("ERROR_CODE_DECODER") ||
            errorCodeName.startsWith("ERROR_CODE_DECODING") ->
            "Your device cannot decode this video format."
        errorCodeName.startsWith("ERROR_CODE_DRM") ->
            "This video is DRM-protected and cannot be played in the app."
        else -> "Could not play this video. Tap to retry."
    }.also {
        android.util.Log.d(
            "CentryChat/Video",
            "humanReadableError: $errorCodeName (code=$errorCode) / cause=${cause?.javaClass?.simpleName}: ${cause?.message}",
        )
    }
}

// ────────────────────────────────────────────────────────────────────────────
// FALLBACK CARD + ERROR OVERLAY (unchanged from previous version)
// ────────────────────────────────────────────────────────────────────────────

@Composable
private fun FallbackOpenOriginalCard(
    originalUrl: String,
    message: String,
) {
    val context = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            imageVector = Icons.Filled.OpenInNew,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(32.dp),
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = message,
            color = Color.White,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodySmall,
        )
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                if (originalUrl.isNotBlank()) {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(originalUrl))
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        context.startActivity(intent)
                    } catch (_: Exception) {
                        // No app to handle — silent.
                    }
                }
            },
        ) {
            Text("Open original")
        }
    }
}

@Composable
private fun ErrorOverlay(
    message: String,
    retryHint: String? = null,
    onRetry: (() -> Unit)? = null,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            imageVector = Icons.Filled.ErrorOutline,
            contentDescription = "Video error",
            tint = MaterialTheme.colorScheme.error,
            modifier = Modifier.size(40.dp),
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = message,
            color = Color.White,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodySmall,
        )
        if (onRetry != null && retryHint != null) {
            Spacer(Modifier.height(8.dp))
            Button(onClick = onRetry) {
                Text(retryHint)
            }
        }
    }
}

// ────────────────────────────────────────────────────────────────────────────
// RESOLVER STATE (for the Unknown URL fallback path)
// ────────────────────────────────────────────────────────────────────────────

private sealed interface ResolverState {
    data object Idle : ResolverState
    data object Loading : ResolverState
    data class Resolved(val media: ResolvedMediaDto) : ResolverState
    data class Failed(val message: String) : ResolverState
}

// ────────────────────────────────────────────────────────────────────────────
// CLICK-CONSUME HELPER — prevents the parent Card's onClick from firing
// when the user taps the video player area.
// ────────────────────────────────────────────────────────────────────────────

/**
 * Returns a [Modifier] that consumes tap events with no visible indication
 * (no ripple, no highlight). Used on the video player's outer Box so the
 * parent `Card(onClick = ...)` (e.g. FeedScreen.PostCard) doesn't fire its
 * onClick when the user taps the video area — preventing the "refresh/reload"
 * navigation to PostDetailScreen.
 *
 * The AndroidView (PlayerView / WebView) is rendered ON TOP of this Box's
 * clickable layer, so it still receives its own taps (ExoPlayer play/pause
 * buttons, YouTube embed play button, etc.). Only taps on the empty/black
 * area around the player surface are consumed by this no-op.
 */
@Composable
private fun Modifier.clickableNoOp(): Modifier {
    val interactionSource = remember { MutableInteractionSource() }
    return this.then(
        Modifier.clickable(
            interactionSource = interactionSource,
            indication = null,
        ) { /* no-op — consume the tap */ },
    )
}
