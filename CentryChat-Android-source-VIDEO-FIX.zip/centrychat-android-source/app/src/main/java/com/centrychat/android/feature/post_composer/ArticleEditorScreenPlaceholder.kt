package com.centrychat.android.feature.post_composer

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

/**
 * Placeholder for the article editor screen.
 *
 * The web uses a full MDX rich-text editor (`@mdxeditor/editor`).
 * A native Android equivalent would use a rich text editor library
 * (e.g.Compose Rich Editor). For now, this placeholder shows a
 * "coming soon" message — the underlying POST /api/v1/articles endpoint
 * is already wired up server-side.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArticleEditorScreenPlaceholder(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Article editor") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        Box(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentAlignment = Alignment.Center,
        ) {
            Text("Article editor — coming soon. The web uses an MDX rich-text editor that requires a native Android equivalent for full parity.")
        }
    }
}
