package com.centrychat.android.data.model

import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit tests for the wrapper DTOs introduced to fix the
 * `Fields [id, fullName, username] are required for type UserProfileSummary`
 * and `Fields [id, title, content, author] are required for type ArticleDetailDto`
 * serialization crashes.
 *
 * The JSON samples below were captured via curl on 2026-09-28 against the
 * production backend at https://sentrychat.netlify.app. They verify that:
 *   1. The backend's `data.profile` wrapper deserializes cleanly into
 *      [UserProfileResponse] (whose `.profile` is the [UserProfileSummary]).
 *   2. The backend's `data.article` wrapper deserializes cleanly into
 *      [ArticleDetailResponse] (whose `.article` is the [ArticleDetailDto]).
 *   3. The same JSON samples would have CRASHED the old code that
 *      tried to deserialize `data` directly into the inner DTOs.
 */
class UserProfileAndArticleWrapperTest {

    /** The same Json configuration used by RetrofitFactory.kt. */
    private val json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
        coerceInputValues = true
        isLenient = true
        encodeDefaults = true
    }

    // ────────────────────────────────────────────────────────────────────
    // USER PROFILE (other user) — `data.profile` wrapper
    // ────────────────────────────────────────────────────────────────────

    @Test
    fun `deserializes user profile response with data-dot-profile wrapper without throwing`() {
        // Captured from: curl https://sentrychat.netlify.app/api/v1/users/t09468/profile
        //   (no Cookie needed — public profile endpoint)
        //
        // CRITICAL: the backend wraps the profile under `data.profile` — NOT
        // directly under `data`. The old code declared the API method as
        // `ApiResponse<UserProfileSummary>` which made kotlinx-serialization
        // try to deserialize `data` directly into `UserProfileSummary` and
        // crashed with: "Fields [id, fullName, username] are required for
        // type UserProfileSummary, but they were missing at path: $.data"
        // because `data` actually contains a `profile` field, not the
        // profile's fields directly.
        //
        // The fix: declare the API method as `ApiResponse<UserProfileResponse>`
        // where `UserProfileResponse` is `data class UserProfileResponse(val
        // profile: UserProfileSummary)`. The repository then extracts `.profile`.
        val raw = """
            {"ok":true,"data":{"profile":{"id":"cmulen9hq0000jq09syqsh0uh","fullName":"Test User","username":"t09468","avatarColor":"#b45309","avatarUrl":null,"isVerified":false,"bio":null,"followersCount":0,"followingCount":0,"postsCount":0,"isFollowing":false,"isFollowedBy":false}}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<UserProfileResponse>>(raw)

        assertTrue(response.ok)
        assertNotNull(response.data)
        assertNotNull(response.data?.profile)
        val profile = response.data?.profile!!
        assertEquals("cmulen9hq0000jq09syqsh0uh", profile.id)
        assertEquals("Test User", profile.fullName)
        assertEquals("t09468", profile.username)
        assertEquals("#b45309", profile.avatarColor)
        assertEquals(0L, profile.followersCount)
        assertEquals(0L, profile.followingCount)
        assertEquals(0L, profile.postsCount)
        assertEquals(false, profile.isFollowing)
        assertEquals(false, profile.isFollowedBy)
    }

    @Test
    fun `deserializes user profile error response (user not found) without throwing`() {
        // A non-existent username — the backend should return a 404 with
        // a structured error. This shape doesn't depend on the wrapper
        // (the wrapper only applies to success responses).
        val raw = """{"ok":false,"error":{"message":"User not found."}}"""

        val response = json.decodeFromString<ApiResponse<UserProfileResponse>>(raw)

        assertEquals(false, response.ok)
        assertNull(response.data)
        assertEquals("User not found.", response.error?.message)
    }

    // ────────────────────────────────────────────────────────────────────
    // ARTICLE DETAIL — `data.article` wrapper
    // ────────────────────────────────────────────────────────────────────

    @Test
    fun `deserializes article detail response with data-dot-article wrapper without throwing`() {
        // Captured from: curl https://sentrychat.netlify.app/api/v1/articles/cmsmg2gql0010ffvw5atpn54k
        //   -H "Cookie: messenger_session=..."
        //
        // CRITICAL: the backend wraps the article under `data.article` — NOT
        // directly under `data`. The old code declared the API method as
        // `ApiResponse<ArticleDetailDto>` which made kotlinx-serialization
        // try to deserialize `data` directly into `ArticleDetailDto` and
        // crashed with: "Fields [id, title, content, author] are required for
        // type ArticleDetailDto, but they were missing at path: $.data"
        // because `data` actually contains an `article` field, not the
        // article's fields directly.
        //
        // The fix: declare the API method as `ApiResponse<ArticleDetailResponse>`
        // where `ArticleDetailResponse` is `data class ArticleDetailResponse
        // (val article: ArticleDetailDto)`. The repository then extracts
        // `.article`.
        //
        // Note: the backend also returns `_count: {likes, comments, views}`
        // alongside the duplicated `likeCount`, `commentCount`, `viewCount`
        // at the top level. The `_count` field is silently dropped because
        // `ignoreUnknownKeys = true`.
        val raw = """
            {"ok":true,"data":{"article":{"id":"cmsmg2gql0010ffvw5atpn54k","authorId":"cmsmg2fax0001ffvw5nlijtgy","title":"العملات الرقمية ومستقبل الاقتصاد","content":"<h1>العملات الرقمية ومستقبل الاقتصاد</h1><p>المقدمة...</p>","excerpt":"العملات الرقمية ومستقبل الاقتصاد — مقال شامل","coverImage":"https://picsum.photos/seed/art4/1200/630","videoUrl":null,"imageZoom":null,"imagePositionX":null,"imagePositionY":null,"showCoverInArticle":true,"adsEnabled":true,"status":"PUBLISHED","moderationStatus":"APPROVED","publishedAt":"2026-08-09T23:39:20.253Z","readingTime":1,"createdAt":"2026-08-09T23:39:20.254Z","updatedAt":"2026-09-26T12:56:37.594Z","author":{"id":"cmsmg2fax0001ffvw5nlijtgy","fullName":"Editor","username":"editor","avatarColor":null,"avatarUrl":null,"isVerified":true},"_count":{"likes":0,"comments":0,"views":3},"likeCount":0,"commentCount":0,"viewCount":3,"shareCount":0,"isLiked":false,"topicIds":[]}}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<ArticleDetailResponse>>(raw)

        assertTrue(response.ok)
        assertNotNull(response.data)
        assertNotNull(response.data?.article)
        val article = response.data?.article!!
        assertEquals("cmsmg2gql0010ffvw5atpn54k", article.id)
        assertEquals("العملات الرقمية ومستقبل الاقتصاد", article.title)
        assertTrue(article.content.startsWith("<h1>"))
        assertEquals("cmsmg2fax0001ffvw5nlijtgy", article.author.id)
        assertEquals("Editor", article.author.fullName)
        assertEquals("editor", article.author.username)
        assertEquals(0L, article.likeCount)
        assertEquals(3L, article.viewCount)
        assertEquals(false, article.isLiked)
    }

    @Test
    fun `deserializes article detail error response (article not found) without throwing`() {
        val raw = """{"ok":false,"error":{"message":"Article not found."}}"""

        val response = json.decodeFromString<ApiResponse<ArticleDetailResponse>>(raw)

        assertEquals(false, response.ok)
        assertNull(response.data)
        assertEquals("Article not found.", response.error?.message)
    }
}
