package com.centrychat.android.data.model

import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit tests for the DTO contracts added/fixed in Round 3:
 *   - `GET /api/v1/playlists/{id}` (single playlist) — `data.playlist`
 *     wrapper (root cause of "Fields [id, name, slug] are required for
 *     type PlaylistDto at path: S.data" SerializationException)
 *   - Backend field names corrected: `isPublic` (boolean) instead of
 *     Android's previous `visibility` (string), `itemCount` (number)
 *     instead of Android's previous `itemsCount` (number), `coverImage`
 *     (string|null) — all mapped via @SerialName.
 */
class PlaylistDetailAndAdminRemovalTest {

    private val json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
        coerceInputValues = true
        isLenient = true
        encodeDefaults = true
    }

    // ────────────────────────────────────────────────────────────────────
    // PLAYLIST DETAIL — GET /api/v1/playlists/{id}
    // ────────────────────────────────────────────────────────────────────

    @Test
    fun `deserializes playlist detail with data-dot-playlist wrapper without throwing`() {
        // Mirrors the shape returned by GET /api/v1/playlists/{id}
        // (see src/app/api/v1/playlists/[id]/route.ts →
        //   `return ok({ playlist: serializePlaylist(playlist) })`).
        //
        // CRITICAL: the backend wraps the playlist under `data.playlist`
        // — NOT directly under `data`. The old code declared the API
        // method as `ApiResponse<PlaylistDto>` which made
        // kotlinx-serialization try to deserialize `data` directly into
        // `PlaylistDto` and crashed with:
        //   `Fields [id, name, slug] are required for type with serial
        //    name 'com.centrychat.android.data.model.PlaylistDto', but
        //    they were missing at path: S.data`
        // because `data` actually contains a `playlist` field, not the
        // playlist's fields directly.
        //
        // The fix: declare the API method as
        // `ApiResponse<PlaylistDetailResponse>` where
        // `PlaylistDetailResponse` is
        // `data class PlaylistDetailResponse(val playlist: PlaylistDto?)`.
        // The repository then extracts `.playlist`.
        val raw = """
            {"ok":true,"data":{"playlist":{"id":"pl-1","ownerId":"u1","name":"My Playlist","slug":"my-playlist","description":"Some desc","coverImage":"https://example.com/cover.jpg","isPublic":true,"createdAt":"2026-09-15T10:00:00.000Z","updatedAt":"2026-09-30T08:00:00.000Z","owner":{"id":"u1","fullName":"Alice","username":"alice","avatarColor":"#b45309","avatarUrl":null,"isVerified":false},"itemCount":3}}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<PlaylistDetailResponse>>(raw)

        assertTrue(response.ok)
        assertNotNull(response.data)
        val playlist = response.data?.playlist
        assertNotNull(playlist)
        assertEquals("pl-1", playlist?.id)
        assertEquals("My Playlist", playlist?.name)
        assertEquals("my-playlist", playlist?.slug)
        assertEquals("Some desc", playlist?.description)
        assertEquals("https://example.com/cover.jpg", playlist?.coverImage)
        // isPublic=true → visibility="PUBLIC" (via @SerialName)
        assertEquals("PUBLIC", playlist?.visibility)
        // itemCount=3 → itemsCount=3 (via @SerialName)
        assertEquals(3L, playlist?.itemsCount)
        assertEquals("2026-09-15T10:00:00.000Z", playlist?.createdAt)
        assertEquals("2026-09-30T08:00:00.000Z", playlist?.updatedAt)
    }

    @Test
    fun `deserializes playlist detail with isPublic=false maps to PRIVATE`() {
        // Edge case: a private playlist → backend sends isPublic=false
        // → Android's visibility property should be "PRIVATE".
        val raw = """
            {"ok":true,"data":{"playlist":{"id":"pl-2","name":"Private","slug":"private","isPublic":false,"itemCount":0,"createdAt":"2026-09-15T10:00:00.000Z"}}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<PlaylistDetailResponse>>(raw)

        assertEquals("PRIVATE", response.data?.playlist?.visibility)
        assertEquals(0L, response.data?.playlist?.itemsCount)
    }

    @Test
    fun `deserializes playlist detail with null fields`() {
        // Edge case: a playlist with no description + no cover image +
        // no updatedAt.
        val raw = """
            {"ok":true,"data":{"playlist":{"id":"pl-3","name":"Minimal","slug":"minimal","description":null,"coverImage":null,"isPublic":false,"itemCount":1,"createdAt":"2026-09-15T10:00:00.000Z","updatedAt":null}}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<PlaylistDetailResponse>>(raw)

        val playlist = response.data?.playlist
        assertEquals("pl-3", playlist?.id)
        assertNull(playlist?.description)
        assertNull(playlist?.coverImage)
        assertNull(playlist?.updatedAt)
        assertEquals("PRIVATE", playlist?.visibility)
        assertEquals(1L, playlist?.itemsCount)
    }

    @Test
    fun `deserializes playlist detail error response (playlist not found) without throwing`() {
        val raw = """{"ok":false,"error":{"message":"Playlist not found."}}"""

        val response = json.decodeFromString<ApiResponse<PlaylistDetailResponse>>(raw)

        assertFalse(response.ok)
        assertNull(response.data)
        assertEquals("Playlist not found.", response.error?.message)
    }

    @Test
    fun `deserializes playlist list response (multiple playlists) with new isPublic + itemCount fields`() {
        // The list endpoint (GET /api/v1/playlists) returns a list with
        // the same field names. Verify the @SerialName mapping works for
        // the list case too.
        val raw = """
            {"ok":true,"data":{"playlists":[{"id":"pl-1","name":"Public List","slug":"public-list","isPublic":true,"itemCount":5,"createdAt":"2026-09-15T10:00:00.000Z"},{"id":"pl-2","name":"Private List","slug":"private-list","isPublic":false,"itemCount":2,"createdAt":"2026-09-16T10:00:00.000Z"}]}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<PlaylistsListResponse>>(raw)

        assertTrue(response.ok)
        val playlists = response.data?.playlists
        assertEquals(2, playlists?.size)
        assertEquals("PUBLIC", playlists?.get(0)?.visibility)
        assertEquals(5L, playlists?.get(0)?.itemsCount)
        assertEquals("PRIVATE", playlists?.get(1)?.visibility)
        assertEquals(2L, playlists?.get(1)?.itemsCount)
    }

    @Test
    fun `deserializes user playlists endpoint with extra total + page + limit fields ignored`() {
        // GET /api/v1/users/{username}/playlists returns extra fields
        // (total, page, limit) — `ignoreUnknownKeys = true` silently
        // drops them.
        val raw = """
            {"ok":true,"data":{"playlists":[],"total":0,"page":1,"limit":100}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<PlaylistsListResponse>>(raw)

        assertTrue(response.ok)
        assertEquals(0, response.data?.playlists?.size)
    }
}
