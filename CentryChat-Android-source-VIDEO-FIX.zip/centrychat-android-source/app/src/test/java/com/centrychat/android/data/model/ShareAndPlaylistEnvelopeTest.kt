package com.centrychat.android.data.model

import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit tests for the DTO contracts added for:
 *   - Post + Article Share endpoints (`POST /api/v1/{posts|articles}/{id}/share`)
 *   - Playlist items endpoint (`GET /api/v1/playlists/{id}/items`) — the
 *     root cause of the "playlist detail shows empty" bug.
 *
 * The JSON samples mirror the EXACT shapes returned by the production
 * CentryChat backend (verified against the backend source in
 * `src/app/api/v1/posts/[id]/share/route.ts`,
 * `src/app/api/v1/articles/[id]/share/route.ts`,
 * `src/app/api/v1/playlists/[id]/items/route.ts` + `src/lib/playlists/index.ts`).
 */
class ShareAndPlaylistEnvelopeTest {

    private val json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
        coerceInputValues = true
        isLenient = true
        encodeDefaults = true
    }

    // ────────────────────────────────────────────────────────────────────
    // POST SHARE — POST /api/v1/posts/{id}/share
    // ────────────────────────────────────────────────────────────────────

    @Test
    fun `deserializes post share response with shared + shareCount`() {
        // Mirrors src/app/api/v1/posts/[id]/share/route.ts → `ok({ shared: true, shareCount })`.
        val raw = """{"ok":true,"data":{"shared":true,"shareCount":5}}""".trimIndent()

        val response = json.decodeFromString<ApiResponse<ShareResponse>>(raw)

        assertTrue(response.ok)
        assertNotNull(response.data)
        assertEquals(true, response.data?.shared)
        assertEquals(5L, response.data?.shareCount)
    }

    @Test
    fun `deserializes post share error response without throwing`() {
        // A 4xx/5xx error from the share endpoint.
        val raw = """{"ok":false,"error":{"message":"Post not found."}}"""

        val response = json.decodeFromString<ApiResponse<ShareResponse>>(raw)

        assertFalse(response.ok)
        assertNull(response.data)
        assertEquals("Post not found.", response.error?.message)
    }

    // ────────────────────────────────────────────────────────────────────
    // ARTICLE SHARE — POST /api/v1/articles/{id}/share
    // ────────────────────────────────────────────────────────────────────

    @Test
    fun `deserializes article share response with shared + shareCount`() {
        // Mirrors src/app/api/v1/articles/[id]/share/route.ts → `ok({ shared: true, shareCount })`.
        val raw = """{"ok":true,"data":{"shared":true,"shareCount":12}}""".trimIndent()

        val response = json.decodeFromString<ApiResponse<ShareResponse>>(raw)

        assertTrue(response.ok)
        assertEquals(true, response.data?.shared)
        assertEquals(12L, response.data?.shareCount)
    }

    @Test
    fun `deserializes article share error response without throwing`() {
        val raw = """{"ok":false,"error":{"message":"Article not found."}}"""

        val response = json.decodeFromString<ApiResponse<ShareResponse>>(raw)

        assertFalse(response.ok)
        assertEquals("Article not found.", response.error?.message)
    }

    // ────────────────────────────────────────────────────────────────────
    // PLAYLIST ITEMS — GET /api/v1/playlists/{id}/items
    // ────────────────────────────────────────────────────────────────────

    @Test
    fun `deserializes playlist items with hydrated article (articleId not id)`() {
        // Mirrors the shape returned by GET /api/v1/playlists/{id}/items
        // (see src/app/api/v1/playlists/[id]/items/route.ts + src/lib/playlists/index.ts
        // → hydratePlaylistItems). The `article` field uses `articleId`
        // (the DB FK column name), NOT `id` — this is the root cause of
        // the previous bug where the Android client failed to deserialize
        // the items list (kotlinx-serialization threw "Fields [id] are
        // required for ArticleCardDto" because it expected `id`).
        //
        // The fix: [PlaylistArticleDto] uses @SerialName("articleId") on
        // its `id` field, so deserialization maps `articleId` JSON key
        // → `id` Kotlin property. The previous code declared
        // `article: ArticleCardDto?` which has a REQUIRED `id` field —
        // that crashed.
        val raw = """
            {"ok":true,"data":{"items":[{"id":"pli-1","playlistId":"pl-1","articleId":"art-1","position":1,"addedAt":"2026-09-15T10:00:00.000Z","article":{"articleId":"art-1","title":"First article","excerpt":"A short summary","coverImage":"https://example.com/img.jpg","videoUrl":"https://example.com/v.mp4","imageZoom":null,"imagePositionX":null,"imagePositionY":null,"publishedAt":"2026-09-14T08:00:00.000Z","readingTime":5,"author":{"id":"u1","fullName":"Alice","username":"alice","avatarColor":"#b45309","avatarUrl":null,"isVerified":false,"isFollowing":false,"isFollowedBy":false}}}]}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<PlaylistItemsResponse>>(raw)

        assertTrue(response.ok)
        assertNotNull(response.data)
        val items = response.data?.items
        assertNotNull(items)
        assertEquals(1, items?.size)
        val item = items?.first()
        assertEquals("pli-1", item?.id)
        assertEquals("pl-1", item?.playlistId)
        assertEquals("art-1", item?.articleId)
        assertEquals(1L, item?.position)
        assertEquals("2026-09-15T10:00:00.000Z", item?.addedAt)
        // The hydrated `article` field — with `articleId` (not `id`).
        val article = item?.article
        assertNotNull(article)
        // The @SerialName("articleId") maps the JSON's `articleId` to the
        // Kotlin `id` property, so `article?.id` returns the article ID.
        assertEquals("art-1", article?.id)
        assertEquals("First article", article?.title)
        assertEquals("A short summary", article?.excerpt)
        assertEquals("https://example.com/img.jpg", article?.coverImage)
        assertEquals("https://example.com/v.mp4", article?.videoUrl)
        assertEquals("2026-09-14T08:00:00.000Z", article?.publishedAt)
        assertEquals(5, article?.readingTime)
        // The author inside the hydrated article.
        assertEquals("u1", article?.author?.id)
        assertEquals("Alice", article?.author?.fullName)
        assertEquals("alice", article?.author?.username)
    }

    @Test
    fun `deserializes playlist items with multiple items + null article`() {
        // Edge case: an item references a non-PUBLISHED article → the
        // backend's hydrate function returns `article: null` for that
        // row. The Android client must NOT crash — it should render a
        // minimal fallback row (handled in the UI).
        val raw = """
            {"ok":true,"data":{"items":[{"id":"pli-1","playlistId":"pl-1","articleId":"art-1","position":1,"addedAt":"2026-09-15T10:00:00.000Z","article":{"articleId":"art-1","title":"Article 1","excerpt":null,"coverImage":null,"videoUrl":null,"imageZoom":null,"imagePositionX":null,"imagePositionY":null,"publishedAt":null,"readingTime":null,"author":{"id":"u1","fullName":"Alice","username":"alice","avatarColor":null,"avatarUrl":null,"isVerified":false,"isFollowing":false,"isFollowedBy":false}}},{"id":"pli-2","playlistId":"pl-1","articleId":"art-2","position":2,"addedAt":"2026-09-15T10:01:00.000Z","article":null}]}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<PlaylistItemsResponse>>(raw)

        assertTrue(response.ok)
        val items = response.data?.items
        assertEquals(2, items?.size)
        assertEquals("art-1", items?.get(0)?.article?.id)
        assertNull(items?.get(1)?.article) // hydrated article missing (draft)
    }

    @Test
    fun `deserializes empty playlist items without throwing`() {
        val raw = """{"ok":true,"data":{"items":[]}}"""

        val response = json.decodeFromString<ApiResponse<PlaylistItemsResponse>>(raw)

        assertTrue(response.ok)
        assertEquals(0, response.data?.items?.size)
    }

    @Test
    fun `playlist items with extra total + page + limit fields ignored gracefully`() {
        // The /api/v1/users/{username}/playlists endpoint returns extra
        // `total`/`page`/`limit` fields — for the items endpoint the
        // backend doesn't add them, but `ignoreUnknownKeys = true`
        // ensures any future fields are silently dropped.
        val raw = """{"ok":true,"data":{"items":[],"total":0,"page":1,"limit":200}}"""

        val response = json.decodeFromString<ApiResponse<PlaylistItemsResponse>>(raw)

        assertTrue(response.ok)
        assertEquals(0, response.data?.items?.size)
    }

    // ────────────────────────────────────────────────────────────────────
    // ProfileFeedItem sanity (compile-time only — no JSON to test,
    // it's a sealed-class hierarchy local to the ProfileViewModel).
    // ────────────────────────────────────────────────────────────────────
    // The ProfileFeedItem sealed class is declared in ProfileViewModel.kt
    // and is not @Serializable (it's a UI-only wrapper). We test it
    // indirectly via the ProfileViewModel's `feed` StateFlow in the
    // end-to-end build verification — the compileDebugKotlin task
    // already verifies the sealed-class hierarchy compiles.
}
