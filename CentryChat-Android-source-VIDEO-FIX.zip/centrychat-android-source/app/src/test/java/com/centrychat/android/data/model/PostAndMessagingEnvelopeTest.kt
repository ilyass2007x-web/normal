package com.centrychat.android.data.model

import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit tests for the DTO contract fixes added for the
 * "Fields [...] are required for type PostDto" and
 * "Field 'conversationId' is required for type MessageDto"
 * serialization crashes.
 *
 * The JSON samples below mirror the EXACT shapes returned by the
 * production CentryChat backend (verified against the backend source
 * in src/app/api/v1/posts/route.ts, src/app/api/v1/posts/[id]/route.ts,
 * src/app/api/v1/conversations/route.ts, and
 * src/app/api/v1/conversations/[id]/messages/route.ts of the web app).
 *
 * They verify:
 *   1. POST /api/v1/posts → `{ ok:true, data:{ post: PostDTO } }`
 *      deserializes cleanly into `ApiResponse<PostEnvelope>`.
 *   2. GET /api/v1/posts/{id} → same shape as above.
 *   3. GET /api/v1/conversations →
 *      `{ ok:true, data:{ conversations: ConversationListItem[] } }`
 *      where each item's `lastMessage` has the SMALLER shape
 *      `{ id, content, senderId, createdAt, deletedAt }` (no
 *      `conversationId`). This is the exact bug the user reported.
 *   4. POST /api/v1/conversations/{id}/messages →
 *      `{ ok:true, data:{ message: MessageDTO } }` deserializes cleanly
 *      into `ApiResponse<MessageEnvelope>`.
 *   5. The same JSON samples would have CRASHED the old code that
 *      tried to deserialize `data` directly into the inner DTOs.
 */
class PostAndMessagingEnvelopeTest {

    /** The same Json configuration used by RetrofitFactory.kt. */
    private val json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
        coerceInputValues = true
        isLenient = true
        encodeDefaults = true
    }

    // ────────────────────────────────────────────────────────────────────
    // POST ENVELOPE — POST /api/v1/posts and GET /api/v1/posts/{id}
    // ────────────────────────────────────────────────────────────────────

    @Test
    fun `deserializes create-post response with data-dot-post wrapper without throwing`() {
        // Mirrors the shape returned by POST /api/v1/posts (see
        // src/app/api/v1/posts/route.ts → `return ok({ post: postWithCounts })`).
        //
        // CRITICAL: the backend wraps the post under `data.post` — NOT
        // directly under `data`. The old code declared the API method as
        // `ApiResponse<PostDto>` which made kotlinx-serialization try to
        // deserialize `data` directly into `PostDto` and crashed with:
        //   `Fields [id, content, createdAt, author] are required for type
        //    with serial name 'com.centrychat.android.data.model.PostDto',
        //    but they were missing at path: S.data`
        // because `data` actually contains a `post` field, not the post's
        // fields directly.
        //
        // The fix: declare the API method as `ApiResponse<PostEnvelope>`
        // where `PostEnvelope` is `data class PostEnvelope(val post: PostDto)`.
        // The repository then extracts `.post`.
        val raw = """
            {"ok":true,"data":{"post":{"id":"cmulen9hq0000jq09syqsh0uh","content":"Hello world","createdAt":"2026-09-28T15:31:09.903Z","updatedAt":"2026-09-28T15:31:09.903Z","author":{"id":"cmulgzn1n0000jq09syqsh0uh","fullName":"Test User","username":"t09468","avatarColor":"#b45309","avatarUrl":null,"isVerified":false,"isFollowing":false,"isFollowedBy":false},"likeCount":0,"commentCount":0,"viewCount":0,"shareCount":0,"isLiked":false,"topicIds":[]}}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<PostEnvelope>>(raw)

        assertTrue(response.ok)
        assertNotNull(response.data)
        val post = response.data?.post
        assertNotNull(post)
        assertEquals("cmulen9hq0000jq09syqsh0uh", post?.id)
        assertEquals("Hello world", post?.content)
        assertEquals("2026-09-28T15:31:09.903Z", post?.createdAt)
        assertEquals("t09468", post?.author?.username)
        assertEquals(0L, post?.likeCount)
        assertEquals(false, post?.isLiked)
    }

    @Test
    fun `deserializes get-post-by-id response without throwing`() {
        // Same shape as POST — the backend's GET /api/v1/posts/{id}
        // also returns `{ ok:true, data:{ post: PostDTO } }` (see
        // src/app/api/v1/posts/[id]/route.ts → `return ok({ post: postDTO })`).
        val raw = """
            {"ok":true,"data":{"post":{"id":"post-abc","content":"Single post","createdAt":"2026-08-09T23:39:20.253Z","updatedAt":"2026-09-26T12:56:37.594Z","author":{"id":"u1","fullName":"Alice","username":"alice","avatarColor":null,"avatarUrl":null,"isVerified":true,"isFollowing":false,"isFollowedBy":true},"likeCount":5,"commentCount":2,"viewCount":10,"shareCount":1,"isLiked":true,"topicIds":["t1","t2"]}}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<PostEnvelope>>(raw)

        assertTrue(response.ok)
        val post = response.data?.post
        assertNotNull(post)
        assertEquals("post-abc", post?.id)
        assertEquals("alice", post?.author?.username)
        assertEquals(true, post?.author?.isVerified)
        assertEquals(true, post?.author?.isFollowedBy)
        assertEquals(5L, post?.likeCount)
        assertEquals(true, post?.isLiked)
        assertEquals(listOf("t1", "t2"), post?.topicIds)
    }

    @Test
    fun `deserializes post error response without throwing`() {
        // A 4xx/5xx response — the backend doesn't wrap errors under `post`,
        // it sends the standard `{ ok:false, error:{ message:"..." } }` shape.
        val raw = """{"ok":false,"error":{"message":"Post not found."}}"""

        val response = json.decodeFromString<ApiResponse<PostEnvelope>>(raw)

        assertFalse(response.ok)
        assertNull(response.data)
        assertEquals("Post not found.", response.error?.message)
    }

    // ────────────────────────────────────────────────────────────────────
    // CONVERSATIONS LIST — GET /api/v1/conversations
    // ────────────────────────────────────────────────────────────────────

    @Test
    fun `deserializes conversations list with lastMessage WITHOUT conversationId`() {
        // Mirrors the shape returned by GET /api/v1/conversations
        // (see src/lib/messaging.ts → ConversationListItem).
        //
        // CRITICAL: the backend's `lastMessage` shape is the SMALLER
        // { id, content, senderId, createdAt, deletedAt } — it does NOT
        // include `conversationId` (the parent conversation already has
        // `id`). The old code declared `ConversationDto.lastMessage` as
        // `MessageDto?` where `MessageDto` REQUIRES `conversationId` —
        // this crashed with:
        //   `Field 'conversationId' is required for type with serial name
        //    'com.centrychat.android.data.model.MessageDto', but it was
        //    missing at path: S.data.conversations[0].lastMessage`
        //
        // The fix: introduce [ConversationLastMessageDto] matching the
        // actual backend shape. We did NOT make `conversationId` nullable
        // on MessageDto (the user explicitly forbade "making fields
        // nullable to hide the bug").
        //
        // The `otherUser` field is also tested — the backend uses this
        // name (not `participant`); the Android DTO uses @SerialName to
        // map `otherUser` → `participant` so existing UI keeps compiling.
        val raw = """
            {"ok":true,"data":{"conversations":[{"id":"conv-1","type":"DIRECT","title":"Alice","otherUser":{"id":"u2","fullName":"Alice","username":"alice","avatarColor":"#b45309","avatarUrl":null,"isVerified":true,"status":"ACTIVE","lastSeenAt":"2026-09-28T15:31:23.729Z"},"lastMessage":{"id":"m1","content":"Hi there","senderId":"u2","createdAt":"2026-09-28T15:31:23.729Z","deletedAt":null},"unreadCount":3,"updatedAt":"2026-09-28T15:31:23.729Z"}]}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<ConversationsListResponse>>(raw)

        assertTrue(response.ok)
        assertNotNull(response.data)
        val conversations = response.data?.conversations
        assertNotNull(conversations)
        assertEquals(1, conversations?.size)
        val conv = conversations?.first()
        assertEquals("conv-1", conv?.id)
        assertEquals("Alice", conv?.title)
        assertEquals("DIRECT", conv?.type)
        // The `otherUser` field maps to `participant` via @SerialName.
        assertEquals("alice", conv?.participant?.username)
        assertEquals(true, conv?.participant?.isVerified)
        // The `lastMessage` deserializes with the SMALLER shape — no crash.
        val last = conv?.lastMessage
        assertNotNull(last)
        assertEquals("m1", last?.id)
        assertEquals("Hi there", last?.content)
        assertEquals("u2", last?.senderId)
        assertEquals("2026-09-28T15:31:23.729Z", last?.createdAt)
        assertNull(last?.deletedAt)
        assertEquals(3L, conv?.unreadCount)
    }

    @Test
    fun `deserializes conversations list with null lastMessage without throwing`() {
        // Edge case: a brand-new conversation with no messages yet.
        // The backend sends `lastMessage: null` — must not crash.
        val raw = """
            {"ok":true,"data":{"conversations":[{"id":"conv-2","type":"DIRECT","title":"Bob","otherUser":{"id":"u3","fullName":"Bob","username":"bob","avatarColor":null,"avatarUrl":null,"isVerified":false,"status":"ACTIVE","lastSeenAt":"2026-09-28T15:31:23.729Z"},"lastMessage":null,"unreadCount":0,"updatedAt":"2026-09-28T15:31:23.729Z"}]}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<ConversationsListResponse>>(raw)

        assertTrue(response.ok)
        val conv = response.data?.conversations?.first()
        assertEquals("conv-2", conv?.id)
        assertNull(conv?.lastMessage)
        assertEquals(0L, conv?.unreadCount)
    }

    @Test
    fun `deserializes conversations list with deleted lastMessage`() {
        // The backend sets `deletedAt` (not `isDeleted`) when a message
        // has been soft-deleted. The `lastMessage.content` is replaced
        // with "[message deleted]" by the backend (not the client).
        val raw = """
            {"ok":true,"data":{"conversations":[{"id":"conv-3","type":"DIRECT","title":"Carol","otherUser":{"id":"u4","fullName":"Carol","username":"carol","avatarColor":null,"avatarUrl":null,"isVerified":false,"status":"ACTIVE","lastSeenAt":"2026-09-28T15:31:23.729Z"},"lastMessage":{"id":"m2","content":"[message deleted]","senderId":"u4","createdAt":"2026-09-28T15:31:23.729Z","deletedAt":"2026-09-28T16:00:00.000Z"},"unreadCount":0,"updatedAt":"2026-09-28T15:31:23.729Z"}]}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<ConversationsListResponse>>(raw)

        assertTrue(response.ok)
        val last = response.data?.conversations?.first()?.lastMessage
        assertNotNull(last)
        assertEquals("[message deleted]", last?.content)
        assertEquals("2026-09-28T16:00:00.000Z", last?.deletedAt)
    }

    @Test
    fun `deserializes empty conversations list without throwing`() {
        // Edge case: a user with no conversations.
        val raw = """{"ok":true,"data":{"conversations":[]}}"""

        val response = json.decodeFromString<ApiResponse<ConversationsListResponse>>(raw)

        assertTrue(response.ok)
        assertEquals(0, response.data?.conversations?.size)
    }

    // ────────────────────────────────────────────────────────────────────
    // MESSAGE ENVELOPE — POST /api/v1/conversations/{id}/messages
    // ────────────────────────────────────────────────────────────────────

    @Test
    fun `deserializes send-message response with data-dot-message wrapper without throwing`() {
        // Mirrors the shape returned by POST /api/v1/conversations/{id}/messages
        // (see src/app/api/v1/conversations/[id]/messages/route.ts →
        // `return ok({ message })`).
        //
        // The backend's MessageDTO includes `conversationId`, `senderName`,
        // `mine`, `editedAt`, `deletedAt`, `readAt` — these now match the
        // updated [MessageDto]. The old [MessageDto] had `isEdited` /
        // `isDeleted` boolean fields which the backend NEVER populated
        // (it sent `editedAt` / `deletedAt` instead) — a silent data bug.
        val raw = """
            {"ok":true,"data":{"message":{"id":"m3","conversationId":"conv-1","senderId":"u1","senderName":"Test User","content":"Hello back","createdAt":"2026-09-28T15:32:00.000Z","readAt":null,"editedAt":null,"deletedAt":null,"mine":true}}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<MessageEnvelope>>(raw)

        assertTrue(response.ok)
        assertNotNull(response.data)
        val msg = response.data?.message
        assertNotNull(msg)
        assertEquals("m3", msg?.id)
        assertEquals("conv-1", msg?.conversationId)
        assertEquals("u1", msg?.senderId)
        assertEquals("Test User", msg?.senderName)
        assertEquals("Hello back", msg?.content)
        assertEquals(true, msg?.mine)
        // Computed `isEdited` / `isDeleted` properties now correctly
        // derive from `editedAt` / `deletedAt` (both null here).
        assertEquals(false, msg?.isEdited)
        assertEquals(false, msg?.isDeleted)
    }

    @Test
    fun `message isEdited property reflects editedAt field correctly`() {
        // When the backend reports an edit, `editedAt` is set — the
        // computed `isEdited` property should now return `true`.
        // The old `isEdited: Boolean` field was ALWAYS false because
        // the backend never sent `isEdited` — it sent `editedAt`.
        val raw = """
            {"ok":true,"data":{"message":{"id":"m4","conversationId":"conv-1","senderId":"u1","senderName":"Test User","content":"edited content","createdAt":"2026-09-28T15:32:00.000Z","readAt":null,"editedAt":"2026-09-28T15:33:00.000Z","deletedAt":null,"mine":true}}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<MessageEnvelope>>(raw)
        val msg = response.data?.message
        assertEquals(true, msg?.isEdited)
        assertEquals(false, msg?.isDeleted)
        assertEquals("2026-09-28T15:33:00.000Z", msg?.editedAt)
    }

    @Test
    fun `message isDeleted property reflects deletedAt field correctly`() {
        // When the backend reports a soft-delete, `deletedAt` is set — the
        // computed `isDeleted` property should return `true`.
        val raw = """
            {"ok":true,"data":{"message":{"id":"m5","conversationId":"conv-1","senderId":"u1","senderName":"Test User","content":"[message deleted]","createdAt":"2026-09-28T15:32:00.000Z","readAt":null,"editedAt":null,"deletedAt":"2026-09-28T15:33:00.000Z","mine":true}}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<MessageEnvelope>>(raw)
        val msg = response.data?.message
        assertEquals(false, msg?.isEdited)
        assertEquals(true, msg?.isDeleted)
    }

    @Test
    fun `deserializes send-message error response without throwing`() {
        // The backend's CSRF check or rate-limiter may reject a send.
        // The error shape is the standard `{ ok:false, error:{...} }`.
        val raw = """{"ok":false,"error":{"message":"Messaging is currently disabled"}}"""

        val response = json.decodeFromString<ApiResponse<MessageEnvelope>>(raw)

        assertFalse(response.ok)
        assertNull(response.data)
        assertEquals("Messaging is currently disabled", response.error?.message)
    }

    // ────────────────────────────────────────────────────────────────────
    // MESSAGES LIST — GET /api/v1/conversations/{id}/messages
    // ────────────────────────────────────────────────────────────────────

    @Test
    fun `deserializes messages list with full MessageDTO shape`() {
        // Mirrors the shape returned by GET /api/v1/conversations/{id}/messages
        // (see src/lib/messaging.ts → MessageDTO). The list endpoint returns
        // the FULL MessageDTO (with `conversationId`, `senderName`, `mine`,
        // `editedAt`, `deletedAt`) — not the smaller lastMessage shape.
        val raw = """
            {"ok":true,"data":{"messages":[{"id":"m1","conversationId":"conv-1","senderId":"u2","senderName":"Alice","content":"Hi","createdAt":"2026-09-28T15:30:00.000Z","readAt":"2026-09-28T15:31:00.000Z","editedAt":null,"deletedAt":null,"mine":false},{"id":"m3","conversationId":"conv-1","senderId":"u1","senderName":"Test User","content":"Hello back","createdAt":"2026-09-28T15:32:00.000Z","readAt":null,"editedAt":null,"deletedAt":null,"mine":true}]}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<MessagesListResponse>>(raw)

        assertTrue(response.ok)
        val messages = response.data?.messages
        assertNotNull(messages)
        assertEquals(2, messages?.size)
        assertEquals("m1", messages?.get(0)?.id)
        assertEquals("Alice", messages?.get(0)?.senderName)
        assertEquals(false, messages?.get(0)?.mine)
        assertEquals("m3", messages?.get(1)?.id)
        assertEquals(true, messages?.get(1)?.mine)
    }
}
