package com.centrychat.android.data.model

import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/**
 * Unit tests for [ApiResponse] deserialization.
 *
 * These tests use the REAL JSON payloads captured from the production
 * CentryChat backend (https://sentrychat.netlify.app) on 2026-09-28.
 * They verify that:
 *   1. The previous "Class discriminator was missing" SerializationException
 *      is GONE (sealed-class polymorphism removed).
 *   2. Every real backend response shape deserializes cleanly into the
 *      flat [ApiResponse] data class.
 *   3. The [dataOrThrow] / [dataOrNull] / [errorMessage] extension functions
 *      behave correctly for success, error, and edge-case responses.
 *
 * The JSON samples below were captured via curl against the production
 * deployment — see `ANDROID_APIRESPONSE_SERIALIZATION_FIX_REPORT.md`
 * section "JSON" for the full set of captured responses.
 */
class ApiResponseTest {

    /** The same Json configuration used by RetrofitFactory.kt. */
    private val json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
        coerceInputValues = true
        isLenient = true
        encodeDefaults = true
    }

    // ────────────────────────────────────────────────────────────────────
    // LOGIN — captured from production on 2026-09-28
    // ────────────────────────────────────────────────────────────────────

    @Test
    fun `deserializes login success response without throwing`() {
        // Captured from: curl -X POST https://sentrychat.netlify.app/api/v1/auth/login
        //   -d '{"email":"testrand09468@gmail.com","password":"Password123"}'
        val raw = """
            {"ok":true,"data":{"sessionId":"c5a16cd7-3ef0-4cf8-8f44-d095a70469b6","user":{"id":"cmulen9hq0000jq09syqsh0uh","fullName":"Test User","email":"testrand09468@gmail.com","username":"t09468","emailVerified":"2026-09-28T15:31:09.900Z","role":"USER","status":"ACTIVE","isVerified":false,"lastSeenAt":"2026-09-28T15:31:23.729Z","twoFactorEnabled":false,"bio":null,"avatarColor":"#b45309","avatarUrl":null,"gender":"MALE","dateOfBirth":null,"countryCode":"MA","language":"en","createdAt":"2026-09-28T15:31:09.903Z"},"requiresVerification":false}}
        """.trimIndent()

        // The previous sealed-class version threw SerializationException here.
        // The flat data class version must deserialize cleanly.
        val response = json.decodeFromString<ApiResponse<LoginResponse>>(raw)

        assertTrue(response.ok)
        assertNotNull(response.data)
        assertNull(response.error)
        assertEquals("c5a16cd7-3ef0-4cf8-8f44-d095a70469b6", response.data?.sessionId)
        assertEquals("cmulen9hq0000jq09syqsh0uh", response.data?.user?.id)
        assertEquals("testrand09468@gmail.com", response.data?.user?.email)
        assertEquals("t09468", response.data?.user?.username)
        assertEquals("USER", response.data?.user?.role)
        assertEquals(false, response.data?.requiresVerification)
    }

    @Test
    fun `deserializes login error response (wrong password) without throwing`() {
        // Captured from: curl -X POST https://sentrychat.netlify.app/api/v1/auth/login
        //   -d '{"email":"testrand09468@gmail.com","password":"wrongpass"}'
        // Backend returned HTTP 401 with this body.
        val raw = """{"ok":false,"error":{"message":"Invalid email or password"}}"""

        val response = json.decodeFromString<ApiResponse<LoginResponse>>(raw)

        assertEquals(false, response.ok)
        assertNull(response.data)
        assertNotNull(response.error)
        assertEquals("Invalid email or password", response.error?.message)
    }

    @Test
    fun `deserializes login error response (missing fields) without throwing`() {
        // Captured from: curl -X POST https://sentrychat.netlify.app/api/v1/auth/login
        //   -d '{}'
        // Backend returned HTTP 400 with this body.
        val raw = """{"ok":false,"error":{"message":"Invalid email address"}}"""

        val response = json.decodeFromString<ApiResponse<LoginResponse>>(raw)

        assertEquals(false, response.ok)
        assertEquals("Invalid email address", response.error?.message)
    }

    // ────────────────────────────────────────────────────────────────────
    // REGISTER — captured from production on 2026-09-28
    // ────────────────────────────────────────────────────────────────────

    @Test
    fun `deserializes register success response without throwing`() {
        // Captured from: curl -X POST https://sentrychat.netlify.app/api/v1/auth/register
        //   -d '{"fullName":"Test Two","email":"testrand11063@gmail.com",...}'
        // Backend returned HTTP 200 with this body.
        //
        // NOTE: the register endpoint uses `verificationRequired` (not
        // `requiresVerification` — the field name the login endpoint uses).
        // The Android `LoginResponse` model uses `requiresVerification`
        // (matching the LOGIN response). For the register response, this
        // field defaults to `false` because `ignoreUnknownKeys = true`
        // silently drops the unknown `verificationRequired` key. This is
        // acceptable: the Android client doesn't read this field after
        // register — it only checks `data.user != null` to decide whether
        // the user was auto-logged-in.
        val raw = """
            {"ok":true,"data":{"registered":true,"verificationRequired":false,"sessionId":"fbd81727-b0ca-4922-9e31-5b00f52dec04","user":{"id":"cmulflff80002la09eengdfhn","email":"testrand11063@gmail.com","fullName":"Test Two","role":"USER"}}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<LoginResponse>>(raw)

        assertTrue(response.ok)
        assertNotNull(response.data)
        assertEquals(true, response.data?.registered)
        assertEquals("fbd81727-b0ca-4922-9e31-5b00f52dec04", response.data?.sessionId)
        assertEquals("cmulflff80002la09eengdfhn", response.data?.user?.id)
        assertEquals("testrand11063@gmail.com", response.data?.user?.email)
    }

    @Test
    fun `deserializes register existing-email anti-enumeration response without throwing`() {
        // Captured from: curl -X POST https://sentrychat.netlify.app/api/v1/auth/register
        //   -d '{"email":"testrand09468@gmail.com",...}' (already-registered email)
        // Backend returned HTTP 200 with this body — NO `user` field, NO
        // `sessionId` field. This is the backend's anti-enumeration behavior:
        // it pretends the account was just created so an attacker can't tell
        // whether the email was already registered.
        //
        // CRITICAL: `data.user` MUST be nullable for this to deserialize
        // without throwing MissingFieldException. The previous version had
        // `val user: UserDto` (non-nullable), which would have crashed here.
        val raw = """{"ok":true,"data":{"registered":true,"verificationRequired":true}}"""

        val response = json.decodeFromString<ApiResponse<LoginResponse>>(raw)

        assertTrue(response.ok)
        assertNotNull(response.data)
        assertEquals(true, response.data?.registered)
        // `user` is null because the backend omitted it (anti-enumeration).
        assertNull(response.data?.user)
        assertNull(response.data?.sessionId)
    }

    @Test
    fun `deserializes register error response (missing fields) without throwing`() {
        // Captured from: curl -X POST https://sentrychat.netlify.app/api/v1/auth/register
        //   -d '{"fullName":"X"}'
        // Backend returned HTTP 400 with this body.
        val raw = """{"ok":false,"error":{"message":"Full name must be at least 2 characters"}}"""

        val response = json.decodeFromString<ApiResponse<LoginResponse>>(raw)

        assertEquals(false, response.ok)
        assertEquals("Full name must be at least 2 characters", response.error?.message)
    }

    @Test
    fun `deserializes register error response (non-gmail email) without throwing`() {
        // Captured from: curl -X POST https://sentrychat.netlify.app/api/v1/auth/register
        //   -d '{"email":"test@test.com"}'
        // Backend returned HTTP 400 with this body.
        val raw = """{"ok":false,"error":{"message":"Only @gmail.com email addresses are accepted"}}"""

        val response = json.decodeFromString<ApiResponse<LoginResponse>>(raw)

        assertEquals(false, response.ok)
        assertEquals("Only @gmail.com email addresses are accepted", response.error?.message)
    }

    // ────────────────────────────────────────────────────────────────────
    // AUTH/ME — captured from production on 2026-09-28
    // ────────────────────────────────────────────────────────────────────

    @Test
    fun `deserializes auth-me response (with cookie) without throwing`() {
        // Captured from: curl -X GET https://sentrychat.netlify.app/api/v1/auth/me
        //   -H "Cookie: messenger_session=..."
        val raw = """
            {"ok":true,"data":{"user":{"id":"cmulen9hq0000jq09syqsh0uh","fullName":"Test User","email":"testrand09468@gmail.com","username":"t09468","emailVerified":"2026-09-28T15:31:09.900Z","role":"USER","status":"ACTIVE","isVerified":false,"lastSeenAt":"2026-09-28T15:57:48.198Z","twoFactorEnabled":false,"bio":null,"avatarColor":"#b45309","avatarUrl":null,"gender":"MALE","dateOfBirth":null,"countryCode":"MA","language":"en","createdAt":"2026-09-28T15:31:09.903Z"}}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<AuthMeResponse>>(raw)

        assertTrue(response.ok)
        assertNotNull(response.data?.user)
        assertEquals("cmulen9hq0000jq09syqsh0uh", response.data?.user?.id)
    }

    @Test
    fun `deserializes auth-me response (no cookie) without throwing`() {
        // Captured from: curl -X GET https://sentrychat.netlify.app/api/v1/auth/me
        //   (no Cookie header)
        // Backend returned HTTP 200 + {"user":null} — the `ok` flag is still
        // `true` (the request itself succeeded) but the payload's `user`
        // is explicitly null.
        //
        // CRITICAL: `AuthMeResponse.user` MUST be nullable for this to
        // deserialize without throwing. The previous version had
        // `val user: UserDto` (non-nullable), which would have crashed here.
        val raw = """{"ok":true,"data":{"user":null}}"""

        val response = json.decodeFromString<ApiResponse<AuthMeResponse>>(raw)

        assertTrue(response.ok)
        assertNotNull(response.data)
        assertNull(response.data?.user)
    }

    // ────────────────────────────────────────────────────────────────────
    // FORGOT PASSWORD + LOGOUT — captured from production on 2026-09-28
    // ────────────────────────────────────────────────────────────────────

    @Test
    fun `deserializes forgot-password success response without throwing`() {
        // Captured from: curl -X POST https://sentrychat.netlify.app/api/v1/auth/forgot-password
        //   -d '{"email":"testrand09468@gmail.com"}'
        val raw = """{"ok":true,"data":{"sent":true}}"""

        val response = json.decodeFromString<ApiResponse<GenericMessageResponse>>(raw)

        assertTrue(response.ok)
        assertEquals(true, response.data?.sent)
    }

    @Test
    fun `deserializes logout success response without throwing`() {
        // Captured from: curl -X POST https://sentrychat.netlify.app/api/v1/auth/logout
        //   -H "Cookie: messenger_session=..."
        val raw = """{"ok":true,"data":{"loggedOut":true,"hadUser":true}}"""

        val response = json.decodeFromString<ApiResponse<GenericMessageResponse>>(raw)

        assertTrue(response.ok)
        // `loggedOut` and `hadUser` are not in GenericMessageResponse — they
        // are silently ignored because `ignoreUnknownKeys = true` in the Json
        // config. The generic message response model only captures fields
        // that are commonly-used across multiple endpoints.
    }

    // ────────────────────────────────────────────────────────────────────
    // EXTENSION FUNCTIONS — dataOrThrow / dataOrNull / errorMessage
    // ────────────────────────────────────────────────────────────────────

    @Test
    fun `dataOrThrow returns data on success`() {
        val response = ApiResponse<LoginResponse>(
            ok = true,
            data = LoginResponse(
                sessionId = "abc",
                user = UserDto(id = "1", fullName = "X", email = "x@y.com", username = "x"),
            ),
        )
        val data = response.dataOrThrow()
        assertEquals("abc", data.sessionId)
        assertEquals("1", data.user?.id)
    }

    @Test
    fun `dataOrThrow throws ApiException with server message on error`() {
        val response = ApiResponse<LoginResponse>(
            ok = false,
            error = ApiError(message = "Invalid email or password", code = "AUTH_FAILED"),
        )
        try {
            response.dataOrThrow()
            fail("Expected ApiException")
        } catch (e: ApiException) {
            assertEquals("Invalid email or password", e.message)
            assertEquals("AUTH_FAILED", e.code)
        }
    }

    @Test
    fun `dataOrThrow throws ApiException with generic message when ok=true but data is null`() {
        // Edge case: ok=true but data is null (shouldn't happen with the real
        // backend, but is handled defensively).
        val response = ApiResponse<LoginResponse>(ok = true, data = null)
        try {
            response.dataOrThrow()
            fail("Expected ApiException")
        } catch (e: ApiException) {
            assertEquals("Server returned success with no data.", e.message)
        }
    }

    @Test
    fun `dataOrNull returns data on success and null on error`() {
        val success = ApiResponse<LoginResponse>(ok = true, data = LoginResponse(user = null))
        val error = ApiResponse<LoginResponse>(ok = false, error = ApiError(message = "x"))

        assertNotNull(success.dataOrNull())
        assertNull(error.dataOrNull())
    }

    @Test
    fun `errorMessage returns server message on error and null on success`() {
        val success = ApiResponse<LoginResponse>(ok = true, data = LoginResponse(user = null))
        val error = ApiResponse<LoginResponse>(
            ok = false,
            error = ApiError(message = "Invalid email or password"),
        )

        assertNull(success.errorMessage())
        assertEquals("Invalid email or password", error.errorMessage())
    }
}
